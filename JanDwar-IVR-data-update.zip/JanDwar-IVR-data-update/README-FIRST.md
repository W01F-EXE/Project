# JanDwar — data update for the IVR / WhatsApp service

Generated 2026-09-29 from the JanDwar v2.8 tree. This is a **data drop**, not a
rewrite. The centre research finished and the catalogue grew a lot, so the
numbers, and in two places the *shapes*, changed under you.

Read the four breaking changes before copying anything.

---

## 1. Breaking changes (these will crash or silently misbehave)

### 1.1 `districts.json` is now an object, not a list

It used to decode to a flat list of district names. It now decodes to:

```json
{
  "all":            ["Agra", "Alappuzha", ...],        // 187 names, union of all states
  "with_centre":    [...],                             // 185
  "without_centre": ["Alluri Sitharama Raju", "Dr. B.R. Ambedkar Konaseema"],
  "by_state": {
    "Tamil Nadu": { "all": [...38], "with_centre": [...], "without_centre": [] },
    "Kerala":     { "all": [...14], ... },
    "Karnataka":  { "all": [...31], ... },
    "Andhra Pradesh": { "all": [...29], ... },
    "Uttar Pradesh":  { "all": [...75], ... }
  },
  "note": "..."
}
```

`json.load(f)` followed by anything list-ish (`for d in districts`, `len()`,
`in`) now iterates the **five top-level keys**, not districts. Use
`data["all"]` for the union and `data["by_state"][state]["all"]` for a
state-scoped lookup. Prefer the state-scoped one — see 1.2.

### 1.2 There is now a STATE slot, and it comes *before* DISTRICT

The interview is **9 slots**, in this order:

```
EDUCATION, FAMILY_OCCUPATION, CURRENT_LIVELIHOOD, INTERESTS,
PREFERENCE, MOBILITY, CONSTRAINTS, STATE, DISTRICT
```

Two consequences for the IVR:

* **Never infer the state from the caller's number or assume Tamil Nadu.** Ask
  it. There are 187 districts across 5 states and the names collide
  (Hassan/Hasan, Bijapur, Pratapgarh, Balrampur, Aurangabad…). District
  detection is state-scoped: resolve STATE first, then match the district
  *within that state's list only*.
* If the caller volunteers a district first, back-fill the state from it
  (`stateOfDistrict()` in the reference) rather than asking twice.

`server-data/flow.json` has been regenerated with all 9 slots × 6 languages —
if your prompts come from an older flow.json you are missing the STATE
question entirely.

### 1.3 `centres.json`: 660 records, and **268 of them have no phone number**

Flat list, one object per centre:

```json
{
  "state": "Andhra Pradesh",
  "district": "Anantapur",
  "name": "ICAR KVK, Reddipalli (host: ANGRAU)",
  "address": "Reddipalli (V), Bukkarayasamudram (Mdl), Anantapur - 515 701 ...",
  "phone": "08554-200418 / 9989623825",     // ← may be null or ""
  "trades": "KVK mandate: training of farmers, farm women and rural youth",
  "dairy_course": null,                      // non-null on only 21 records
  "confidence": "CONFIRMED",                 // CONFIRMED | LIKELY | UNVERIFIED
  "confidence_note": "address, phones and location from the KVK's own ...",
  "source": "https://atari-hyderabad.org.in/kvks?lang=en",
  "retrieved": "2026-09-29"
}
```

On a voice call this matters more than it does in the app:

* **`phone` is null/empty on 268 of 660.** Do not synthesise "you can call
  them on" and then read out silence. Branch: read the address instead, and
  offer to SMS/WhatsApp the details.
* **`phone` is often two numbers joined by `/`.** Read one, or the TTS will
  say a 20-digit string. Split on `/` and `,` and take the first.
* **Respect `confidence`.** For `UNVERIFIED` (16 records) do not say "go to
  this centre" — say the district has a listed centre and that the details
  need confirming. Same wording the app uses.
* Phone coverage is very uneven by state, so this is not a rare edge case:

  | State | Centres | CONFIRMED | LIKELY | UNVERIFIED | Has phone |
  |---|---:|---:|---:|---:|---:|
  | Tamil Nadu | 180 | 118 | 58 | 4 | 168 |
  | Kerala | 146 | 99 | 45 | 2 | 112 |
  | Karnataka | 142 | 56 | 83 | 3 | 78 |
  | Uttar Pradesh | 109 | 11 | 98 | 0 | **17** |
  | Andhra Pradesh | 83 | 10 | 66 | 7 | **17** |
  | **Total** | **660** | **294** | **350** | **16** | **392** |

### 1.4 `job_roles.json` has 540 rows but only 476 are usable

64 rows are header/garbage artefacts from the source PDFs. The app and the
server both drop them with the **same** predicate — mirror it exactly or the
phone and the phone-call will recommend different courses:

```python
def is_valid_name(n: str) -> bool:
    n = (n or "").strip()
    return (len(n) > 3
            and n.lower() != "english hindi"
            and not n.startswith("QG-")
            and not n.lower().startswith("qp code"))
```

Row shape: `{job_role, qp_code, sector, ssc, nsqf_level, notional_hours}`.
After filtering: **476 roles across 13 sectors**. Types are now clean in this
drop (no nulls, no bare ints where a string is expected) — but keep the
tolerant parse, the upstream source is not stable.

**All but 3 of the 476 `qp_code` values contain a `/`.** URL-encode the code
before putting it in a path segment or a webhook callback, or the route will
404 on almost every role.

---

## 2. What to copy where

```
assets/            → your server's asset directory (8 JSON files)
server-data/       → flow.json, replaces server/data/flow.json
reference/         → my working implementation. DIFF against yours, don't paste over it.
tools/             → verification scripts, run them after the drop
verify.py          → standalone one-shot sanity check, no dependencies
```

If your service resolves assets the way the reference `data.py` does, the
lookup order is:

1. `$JANDWAR_ASSETS` if set  ← **simplest: point it at this `assets/` folder**
2. `<repo>/app/src/main/assets`
3. `<repo>/assets`
4. `server/assets`

For a standalone deploy, dropping `assets/` in as `server/assets/` works with
no code change and no env var.

`reference/` is there so you can diff, not so you can overwrite. The four
files most likely to need a change on your side are `core/data.py` (loaders +
the 13-sector map), `core/nlu.py` (STATE detection, state-scoped district),
`core/engine.py` (9-slot order, `INFERABLE`) and `channels/ivr.py` (the
per-language Twilio voice map).

---

## 3. Verify the drop

```bash
python3 verify.py assets/          # no dependencies, ~1s
```

Expected tail:

```
OK  centres.json        660 records  294/350/16  phone 392
    note: 268 centres have NO phone number - the IVR must branch on this
OK  districts.json      187 districts, 5 states, 185 with a centre
OK  job_roles.json      540 rows -> 476 valid, 13 sectors
    note: 3 qp_codes contain no '/' (the rest must be URL-encoded in routes)
OK  district_economy    187 districts, 135 with livelihood notes
OK  gia_funding_rules   5 states
OK  i18n.json           156 strings x 6 langs, 17 occupations, 10 interests
OK  lexicon.json        3596 forms, 38 categories
OK  flow.json           9 slots x 6 langs
ALL CHECKS PASSED
```

Then, from the repo root (these need the whole tree, not just this zip):

```bash
python3 tools/check_nlu.py       # 31 cases, 2906/2906 forms resolve
python3 tools/check_answers.py   # 353/353 realistic spoken answers
```

---

## 4. Things that are easy to get wrong on a voice channel

* **Twilio `<Say>` needs an explicit `voice` for every Indian language.** The
  default voice is Basic `man`, which supports a handful of European languages
  only; `<Say language="ta-IN">` with no voice attribute is broken. The map in
  `reference/app/channels/ivr.py`:

  | Lang | Voice |
  |---|---|
  | en | `Google.en-IN-Standard-A` |
  | ta | `Google.ta-IN-Standard-C` |
  | hi | `Google.hi-IN-Standard-A` |
  | te | `Google.te-IN-Standard-C` |
  | kn | `Google.kn-IN-Standard-C` |
  | ml | `Google.ml-IN-Standard-C` |

* **Never hand-edit `lexicon.json`, `i18n.json` or `flow.json`.** They are
  generated. Regenerate with `tools/extract_flow.py` (flow), and the
  `gen_lexicon.py` / `gen_i18n.py` generators in the main tree. A hand edit
  will be silently reverted the next time anyone regenerates, and the app and
  the IVR will drift apart.

* **The 13 sectors are all GIA-fundable.** `gia_funding_rules.json` records,
  per state, that central GIA guidelines place no sector/QP restriction
  ("none stated"). A hardcoded whitelist of sectors has broken this project
  twice — derive it from the data or assert coverage in a test.

* **Say the confidence out loud when it is weak.** The whole point of shipping
  `confidence`, `source` and `retrieved` on every record is that the assistant
  never states an unverified centre as fact. That honesty is a differentiator
  in this problem statement, not an inconvenience.

---

## 5. Counts as of this drop

| Asset | Figure |
|---|---|
| Centres | 660 (294 CONFIRMED / 350 LIKELY / 16 UNVERIFIED), all with a source URL + retrieval date |
| Centres with a phone number | 392 of 660 |
| Districts | 187 across 5 states, 185 with at least one centre |
| District economy notes | 187 entries, 135 with livelihood notes, 52 individually source-verified |
| NSQF roles | 540 rows → 476 valid, 13 sectors, all GIA-fundable |
| Lexicon | 3,596 surface forms, 38 categories, 6 languages |
| UI strings | 156 keys × 6 languages, + 17 occupation labels, + 10 interest labels |
| Interview | 9 slots × 6 languages (`flow.json`, 108 prompts) |
| Tests | 353/353 answer cases, 2,906/2,906 lexicon forms |
