#!/usr/bin/env python3
"""
Standalone sanity check for a JanDwar asset drop. No dependencies.

    python3 verify.py [assets_dir] [--flow path/to/flow.json]

Defaults to ./assets and ./server-data/flow.json. Exits non-zero on any
failure so it can gate a deploy.
"""
from __future__ import annotations

import collections
import json
import pathlib
import sys

FAILURES: list[str] = []
LINES: list[str] = []


def ok(label: str, detail: str) -> None:
    LINES.append(f"OK  {label:<20}{detail}")


def bad(label: str, detail: str) -> None:
    LINES.append(f"FAIL {label:<19}{detail}")
    FAILURES.append(f"{label}: {detail}")


def load(path: pathlib.Path):
    if not path.is_file():
        bad(path.name, "missing")
        return None
    try:
        with path.open(encoding="utf-8") as f:
            return json.load(f)
    except Exception as exc:  # noqa: BLE001
        bad(path.name, f"unparseable: {exc}")
        return None


def is_valid_name(n) -> bool:
    """Exactly the predicate the app and the server use. Keep in sync."""
    n = (n or "").strip() if isinstance(n, str) else ""
    return (len(n) > 3
            and n.lower() != "english hindi"
            and not n.startswith("QG-")
            and not n.lower().startswith("qp code"))


def check_centres(a: pathlib.Path) -> None:
    c = load(a / "centres.json")
    if c is None:
        return
    if not isinstance(c, list):
        bad("centres.json", f"expected a list, got {type(c).__name__}")
        return
    required = {"state", "district", "name", "confidence", "source"}
    missing = [i for i, r in enumerate(c) if not required <= set(r)]
    conf = collections.Counter(r.get("confidence") for r in c)
    phone = sum(1 for r in c if (r.get("phone") or "").strip())
    unknown = set(conf) - {"CONFIRMED", "LIKELY", "UNVERIFIED"}
    nosrc = sum(1 for r in c if not (r.get("source") or "").strip())
    if missing:
        bad("centres.json", f"{len(missing)} records missing required keys "
                            f"(first at index {missing[0]})")
    elif unknown:
        bad("centres.json", f"unexpected confidence values: {sorted(unknown)}")
    elif nosrc:
        bad("centres.json", f"{nosrc} records have no source URL")
    else:
        ok("centres.json", f"{len(c)} records  "
                           f"{conf['CONFIRMED']}/{conf['LIKELY']}/{conf['UNVERIFIED']}  "
                           f"phone {phone}")
        if phone < len(c):
            LINES.append(f"    note: {len(c) - phone} centres have NO phone number - "
                         f"the IVR must branch on this")


def check_districts(a: pathlib.Path) -> None:
    d = load(a / "districts.json")
    if d is None:
        return
    if not isinstance(d, dict) or "by_state" not in d:
        bad("districts.json", "expected an object with 'all' and 'by_state' "
                              "(this file changed shape - see README 1.1)")
        return
    states = d["by_state"]
    total = len(d.get("all", []))
    union = sorted({x for s in states.values() for x in s["all"]})
    if len(union) != total:
        bad("districts.json", f"'all' has {total} but by_state unions to {len(union)}")
    else:
        ok("districts.json", f"{total} districts, {len(states)} states, "
                             f"{len(d.get('with_centre', []))} with a centre")


def check_job_roles(a: pathlib.Path) -> None:
    j = load(a / "job_roles.json")
    if j is None:
        return
    rows = j["roles"] if isinstance(j, dict) and "roles" in j else j
    if not isinstance(rows, list):
        bad("job_roles.json", f"expected a list, got {type(rows).__name__}")
        return
    good = [r for r in rows if is_valid_name(r.get("job_role"))]
    sectors = {r.get("sector") for r in good if r.get("sector")}
    nulls = sum(1 for r in good
                if r.get("nsqf_level") is None or r.get("notional_hours") is None)
    noslash = sum(1 for r in good if "/" not in str(r.get("qp_code", "")))
    if not good:
        bad("job_roles.json", "no valid rows after filtering")
    elif nulls:
        bad("job_roles.json", f"{nulls} valid rows have a null level/hours - "
                              f"the parser must coerce these, not throw")
    else:
        ok("job_roles.json", f"{len(rows)} rows -> {len(good)} valid, "
                             f"{len(sectors)} sectors")
        if noslash:
            LINES.append(f"    note: {noslash} qp_codes contain no '/' "
                         f"(the rest must be URL-encoded in routes)")


def check_economy(a: pathlib.Path) -> None:
    e = load(a / "district_economy.json")
    if e is None:
        return
    if not isinstance(e, dict):
        bad("district_economy", f"expected an object, got {type(e).__name__}")
        return
    notes = sum(1 for v in e.values() if (v.get("livelihood_notes") or "").strip())
    ok("district_economy", f"{len(e)} districts, {notes} with livelihood notes")


def check_gia(a: pathlib.Path) -> None:
    g = load(a / "gia_funding_rules.json")
    if g is None:
        return
    if not isinstance(g, dict) or not g:
        bad("gia_funding_rules", "expected a non-empty state-keyed object")
        return
    ok("gia_funding_rules", f"{len(g)} states")


def check_i18n(a: pathlib.Path) -> None:
    i = load(a / "i18n.json")
    if i is None:
        return
    try:
        langs = [l[0] for l in i["langs"]]
        counts = {k: len(v) for k, v in i["strings"].items()}
    except Exception:  # noqa: BLE001
        bad("i18n.json", "expected keys 'langs' and 'strings'")
        return
    sizes = set(counts.values())
    if len(sizes) != 1:
        bad("i18n.json", f"languages disagree on key count: {counts}")
    elif set(counts) != set(langs):
        bad("i18n.json", f"langs {langs} != strings {sorted(counts)}")
    else:
        ok("i18n.json", f"{sizes.pop()} strings x {len(langs)} langs, "
                        f"{len(i.get('occupation', {}).get('en', []))} occupations, "
                        f"{len(i.get('interest', {}).get('en', []))} interests")


def check_lexicon(a: pathlib.Path) -> None:
    lx = load(a / "lexicon.json")
    if lx is None:
        return
    forms = lx.get("forms", lx) if isinstance(lx, dict) else None
    if not isinstance(forms, dict):
        bad("lexicon.json", "expected an object with a 'forms' map")
        return
    total = sum(len(v) for v in forms.values())
    ok("lexicon.json", f"{total} forms, {len(forms)} categories")


def check_flow(path: pathlib.Path) -> None:
    f = load(path)
    if f is None:
        return
    slots = f.get("slot_order") or []
    langs = f.get("langs") or []
    expected = ["EDUCATION", "FAMILY_OCCUPATION", "CURRENT_LIVELIHOOD", "INTERESTS",
                "PREFERENCE", "MOBILITY", "CONSTRAINTS", "STATE", "DISTRICT"]
    if list(slots) != expected:
        bad("flow.json", f"slot order is {list(slots)}, expected {expected} "
                         f"(regenerate with tools/extract_flow.py)")
        return
    qs = f.get("questions", {})
    missing = [s for s in slots
               if not all(qs.get(s, {}).get(l) for l in langs)]
    if missing:
        bad("flow.json", f"slots missing a translation: {missing}")
    else:
        ok("flow.json", f"{len(slots)} slots x {len(langs)} langs")


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    flow = pathlib.Path("server-data/flow.json")
    if "--flow" in sys.argv:
        flow = pathlib.Path(sys.argv[sys.argv.index("--flow") + 1])
    a = pathlib.Path(args[0]) if args else pathlib.Path("assets")

    here = pathlib.Path(__file__).resolve().parent
    if not a.is_dir() and (here / a).is_dir():
        a = here / a
    if not flow.is_file() and (here / flow).is_file():
        flow = here / flow

    if not a.is_dir():
        print(f"no such assets directory: {a}", file=sys.stderr)
        return 2

    print(f"assets: {a.resolve()}\n")
    check_centres(a)
    check_districts(a)
    check_job_roles(a)
    check_economy(a)
    check_gia(a)
    check_i18n(a)
    check_lexicon(a)
    check_flow(flow)

    print("\n".join(LINES))
    print()
    if FAILURES:
        print(f"{len(FAILURES)} CHECK(S) FAILED")
        return 1
    print("ALL CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
