# Karnataka — JanDwar Data Pack Report

Retrieved: 2026-09-29 · Method: official portals first (.gov.in/.nic.in/bank.in), search-cache mining for fragile CMS portals, aggregators only as UNVERIFIED backup.

## 1. Deliverable 1 — centres.json (142 centres, 31/31 districts)

| Type | Count | Primary source |
|---|---|---|
| Govt ITIs (DET, 4 divisions) | 78 | itiemp.karnataka.gov.in division tables (via cache), detmysurudivision.org, cite.karnataka.gov.in |
| ICAR KVKs | 33 | ataribengaluru.org (ATARI Zone XI official roster) |
| Canara Bank RSETIs | 14 (incl. Harohalli women-only + Haliyal co-sponsored) | canarabank.bank.in CBCRDT official table |
| RUDSETIs | 7 | canarabank.bank.in CBCRDT official table |
| Jan Shikshan Sansthans | 4 | jssonline.org (1), ngo4you.com (3, UNVERIFIED) |
| Other | 6 | CBIIT Malleshwaram, ATIs Jogaradoddi + Karkala, CSR&TI Mysuru (Central Silk Board), GTTC network (28 centres), KGTTI network (5 centres) |

**Confidence: 56 CONFIRMED / 83 LIKELY / 3 UNVERIFIED.**

- CONFIRMED = address/phone from an official page fetched this pass (ATARI gist cards, Canara CBCRDT table, detmysurudivision.org, DGT Model ITI PDF, uasbangalore.edu.in, kvkvijayapura.org, kvkshivamogga.karnataka.gov.in, csrtimys.res.in).
- LIKELY = official portal exists but phone came from an older division principal list republished on document-sharing sites (pdfcoffee/Scribd copies of DET tables), or name-without-contact from official contact pages (cite.karnataka.gov.in). These are digitizations of the same official DET tables — flagged per record.
- UNVERIFIED = 3 JSS records (Davanagere, Tumakuru, Karwar) from an NGO directory.

**Karnataka-specific caveats:**
- itiemp.karnataka.gov.in (DET training-wing contact tables) returns HTTP 500 on direct fetch; rows were reconstructed from search-engine caches of the exact URLs. Phone digits occasionally truncated on the source page itself — noted inline ("as printed; likely 10-digit").
- **Vijayanagara district (2020 reorganisation):** DET tables predate the split; ITIs at Sandur, Hampsagar, Itagi/Hadagali and Gudekote are mapped to Vijayanagara with per-record notes. Ballari keeps ITI(M) Hosur-Rd-style city campuses; KVK Ballari (Hagari) also pre-dates the split and physically serves both.
- **GTTC/KGTTI are network-level records** (one row each naming member cities) because per-centre addresses were not captured this pass — expand before field use.
- Belagavi-division DET table was never directly found; Hubli-division rows came from the same cache set. Some ITI phones duplicate across rows in the source (e.g. Bagepalli, Devadurga) — flagged inline.

## 2. Deliverable 2 — job_roles_additional.json (7 QPs)

| QP | Role | Level | Hours |
|---|---|---|---|
| 2022/TEXT/MoT/05533 | Mulberry Silk Reeler | 2 | **210** (verified on NQR title) |
| 2022/TEXT/MoT/06347 | Mulberry Silk Reeling Manufacturing Operator | 3 | null — hours in PDF, not opened |
| 2019/TEXT/MOT/3173 | Vanya Silk Reeling & Spinning Manufacturer | 4 | **200** (verified on NQR title) |
| TSC/Q2404 | Fitter — Shuttleless Weaving | 3 | **450** (verified on NQR table) |
| AAS/Q1001 | Aerospace CNC Machinist | null | null — NQR PDF not opened |
| AAS/Q0605 | Cabin Crew | null | null — NQR PDF not opened |
| AAS/Q4504 | Airport Terminal Operations Manager | null | null — NQR PDF not opened |

**New sector token introduced: `aerospace_aviation`** (AASSC council) — first use in the project. Silk and weaving QPs reuse `handloom_textile`; they map directly onto Ramanagara/Kolar silk reeling, Gadag powerloom and Kollegal handloom clusters.

## 3. Deliverable 3 — districts.json

31 districts, exact partition (31 with_centre / 0 without_centre), Vijayanagara (carved from Ballari, 2020-21) included; spelling variants listed in notes.

## 4. Deliverable 4 — gia_funding_rules.json

- **State layer (verified):** Dr. B.R. Ambedkar Development Corporation "Prosperity Scheme" — SC, 21–50 y, family income ≤ ₹5 lakh, skill/EDP training + franchise retail-outlet support (yuvakanaja.in). CMKKY (KSDC): free NSQF training 18–35 y, ~3,000 job roles / 35+ sectors, 800+ accredited centres, DSDOs in 30 districts. GTTC 28 centres, KGTTI 5, Siemens CoEs ×4.
- **Central predicate (from TN pass, same scheme):** RPL 32–80 h, STT 200–600 h, EDP 80 h, LTT 6–12 mo, ≥70% placement, ≥30% women, ≤30% infra cap, no QP/sector whitelist.
- **Silence stated plainly:** no Karnataka per-trainee rupee norm or state GIA trade list found in public pages; machine rule KA-GIA-ELIG-001 carries the verified eligibility bands and forbids quoting rupee figures without the MoSJE circular.

## 5. Deliverable 5 — district_economy.json (31 districts)

Officially anchored: Kolar DIP (Narsapura auto hub, Shivarpatna stone carving, silk), Dakshina Kannada DIP (cashew/tile/beedi, gold jewellery), Kodagu DIP (plantation), Chikkaballapura DIP (silk filature), state profile clusters (Gadag powerloom, Hubli agri-implements, Kalaburagi dal mills, Kollegal handloom). **DIPs date to 2015-16/2016-17 — stale, treated LIKELY throughout.** Best GIA-fit district: **Ramanagara** (silk reeling + Channapatna GI toy artisans + women-only RSETI + artisan ATI all co-located).

## 6. Stale / contradictory items

| Item | Issue |
|---|---|
| MSME DIPs & state profile | 2015-16/2016-17 vintage; cluster lists may have moved |
| DET principal list (pdfcoffee/Scribd copies) | Undated digitizations of official tables; phones occasionally truncated/duplicated — per-record flags |
| ATARI KVK table | Ramanagara KVK pin printed as Bengaluru 560065 (city pin) — address left taluk-level |
| RSETI non-Canara sponsors | Bagalkot (Karnataka Bank), Chikkamagaluru + Kodagu-Kudige (Union) from Oct-2024 directory only — LIKELY |
| JSS count | Only 4 of an expected ~10 JSSs found; jss.gov.in is a JS shell — flagged as gap |
| ITI(B) Hosur Rd year | Women's ITI Peenya "est. 01-08-1981" per source row; not cross-checked |

## 7. Where I looked / gaps

Looked: DET + cite + detmysurudivision portals (ITIs), ATARI (KVKs), Canara CBCRDT (RSETI/RUDSETI/ATI/CBIIT), jssonline + ngo4you (JSS), csrtimys.res.in (silk), dcmsme.gov.in (economy), kaushalya.karnataka.gov.in + yuvakanaja.in (state skilling/GIA), nqr.gov.in (QPs), district portals (DSDO).
Gaps: Belagavi-division DET table never found directly; per-centre GTTC/KGTTI addresses; non-Canara RSETI contact details; JSS full roster; NQR aerospace QP hours (PDF); state GIA rupee norms.
