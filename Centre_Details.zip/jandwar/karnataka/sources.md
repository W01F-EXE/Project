# Karnataka Sources (all accessed 2026-09-29)

## Official — fetched directly
1. https://ataribengaluru.org/KVK.html — ATARI Bengaluru Zone XI KVK roster (all 33 KA KVKs: host, year, pin; gist cards with phones) — KVK records
2. https://www.canarabank.bank.in/canara-bank-centenary-rural-development-trust-cbcrdt- — Canara Bank CBCRDT official state table (RSETI 10, RUDSETI 7, ATI 2, CBIIT 1; addresses + mobiles) — RSETI records
3. https://dgt.gov.in/sites/default/files/2024-01/ModelITIBanglore.pdf — DGT Model ITI Bangalore (GU29000014, Hosur Rd, 1,721 seats, principal contact) — ITI(M) Hosur Rd
4. https://detmysurudivision.org/itiinfo.php — DET Mysuru division official ITI table (MIS codes; Kodagu/Chamarajanagar/Mysuru-area ITIs) — division ITIs
5. https://www.uasbangalore.edu.in/en/krishi-vigyan-kendra-bengaluru-rural/ — UAS Bangalore official KVK Bengaluru Rural page (address, phones, demo units)
6. https://kvkvijayapura.org/new/ — KVK Vijayapura official site (Hittnahalli address)
7. https://kvkshivamogga.karnataka.gov.in/en — KVK Shivamogga official site (Navule address)
8. https://www.csrtimys.res.in/contact-us — CSR&TI Mysuru (Central Silk Board): address, phones, training courses/fees — silk anchor centre
9. https://kaushalya.karnataka.gov.in/ + /8/history/en — KSDC/SDEL: CMKKY (18–35 y, ~3,000 NSQF roles, 35+ sectors, 800+ centres), GTTC 28 centres, KGTTI 5, SETU, DSDO coverage — GIA state layer + network centres
10. https://yuvakanaja.in/ — Dr. B.R. Ambedkar Development Corporation: Prosperity Scheme (SC 21–50 y, ≤₹5L, training + franchise) — GIA eligibility
11. https://bangalorerural.nic.in/en/district-skill-development-office/ — District Skill Development Office, Bengaluru Rural — economy/DSDO
12. https://www.nqr.gov.in/ — National Qualification Register: silk QPs with notional hours (210/200), TSC/Q2404 (450 h) — job roles
13. https://dcmsme.gov.in/dips/kolar.pdf, .../dakshina.pdf, .../kodagu.pdf, .../chickballapur.pdf, .../state-profile.pdf — MSME District Industrial Profiles (2016-17; state profile 2015-16 — STALE) — district economy

## Official — reconstructed from search caches (portal returned HTTP 500 on fetch)
14. https://itiemp.karnataka.gov.in/page/CONTACT+US/Training+Wing/en — DET training-wing division ITI tables (Bengaluru/Hubli/Kalaburagi division rows)
15. https://cite.karnataka.gov.in/Home/ContactUs — CITE principal/officer contact page (name-only rows)

## Secondary / UNVERIFIED
16. https://pdfcoffee.com/iti-colleges-in-karnataka-pdf-free.html — undated digitization of DET principal list (older addresses/landlines) — LIKELY ITIs
17. https://www.scribd.com/document/694848754/Hubli-Division-ITI-List — digitization of DET division table — LIKELY ITIs
18. https://www.scribd.com/document/890901945/RSETI-contact-details-10-10-2024 — RSETI directory 10-10-2024 (non-Canara sponsors: Bagalkot=KMB, Chikkamagaluru/Kodagu=Union) — LIKELY
19. https://jssonline.org/wp-content/uploads/2019/06/Application_form-converted.pdf — JSS Mahavidyapeetha application PDF (JSS Mysuru address) — LIKELY
20. https://www.ngo4you.com/list-ngo-india/ngo-karnataka/ — NGO directory (JSS Davanagere/Tumakuru/Karwar) — UNVERIFIED
21. https://pmajay.dosje.gov.in/ — PM-AJAY national portal — GIA reference
22. https://en.wikipedia.org/wiki/List_of_districts_of_Karnataka — 31-district list incl. Vijayanagara — districts.json
