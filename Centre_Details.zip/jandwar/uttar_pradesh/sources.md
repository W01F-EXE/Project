# Uttar Pradesh Sources (all accessed 2026-09-29)

## Official — fetched directly
1. https://icar.org.in/en/node/15021 — ICAR official KVK roster for Uttar Pradesh ("Uttar Pradesh (86)"): address, host organization, sanction year for all 86 UP KVKs (3 chunks fetched) — KVK records
2. https://kvk.icar.gov.in/selected_kvk.aspx?id=k0274 — ICAR KVK Knowledge Network page (KVK Mainpuri: head, phone 9758991541, email)
3. https://www.pnbindia.in/document/agricultural-banking/hopslb_rseti_list.pdf — PNB official RSETI list PDF (UP rows: Baghra-Muzaffarnagar, Bijnor, Budaun, Bulandshahr, Jhansi, Lalitpur, Matki Jharoli-Saharanpur — director phones/emails)
4. https://gitigorakhpur.com/ — Govt ITI Chargawan Gorakhpur official site (GR09000754, principal, phones, vppup.in email)
5. https://www.gitikaraundi.org/pagedetail/360481/locate-us — Govt ITI Karaundi Varanasi official site (phone, address, Maruti Suzuki partnership)
6. https://msme1connect.up.gov.in/scheme-list/training-scheme-for-sc-st — UP govt MSME portal: SC/ST Training Scheme (4-month 1T+3P, toolkit, 18-45y, education rules, GO PDFs) — GIA state layer
7. https://www.upsdm.gov.in/Content/WebAssets/pdfFiles/Uttar_Pradesh_Skill_Development_Policy.pdf — UP Skill Development Policy (STEP-UP >=30% women; SC/ST BPL-proportionality; 3% PwD)
8. https://dcmsme.gov.in/dips/Agra.pdf — MSME-DI Brief Industrial Profile Agra (shoe cluster 5,000 units, carpet cluster 90 units/75,000 employed, Leather Park)
9. https://dcmsme.gov.in/old/dips/Aligarh.pdf — MSME-DI Brief Industrial Profile Aligarh (locks & hardware cluster ~2,500 units, ~10,000 employed)
10. https://ramp.msme.gov.in/ramp/pdf-documents/sip-states/uttar_pradesh.pdf — MSME RAMP UP State Investment Profile (42 handloom clusters; Mirzapur-Bhadohi carpet cluster ~3.2M; ODOP district tables)
11. https://nqr.gov.in/qualification/file/QF_Shoesmith(Cobbler).pdf — NQR PM-Vishwakarma qualification file: Shoesmith (Cobbler), 40:00 hours, approved 14-Sep-2023, NQR NG-2.5-LT-00760-2023-V1-LSSC
12. https://nqr.gov.in/qualification-title?nid=&page=152... — NQR title pages: Footwear Maker ATS/CTS/CTS-DGT (L3, 1600/2580/2080 h)
13. https://www.nqr.gov.in/sites/default/files/Annexure%201_LSS_Q5501_v2.0_Stitcher_Goods&Garments.pdf — LSSC QP LSS/Q5501 (L3, NQR 2022/LT/LSSC/06848)
14. https://hsdm.org.in/doc/qualification_packs/LSS_Q2501_v1.0.pdf — LSSC QP LSS/Q2501 (L4, NQR 2015/LT/LSSC/00386)
15. http://www.slbcup.com/Agenda/SLBC_BOOKLET_June_2016.pdf + Agend_March2015.pdf — SLBC-UP official booklets (75 RSETIs established; last districts Jhansi/Shamli PNB, Sambhal/Hapur Syndicate)
16. https://en.wikipedia.org/wiki/List_of_regional_rural_banks_in_Uttar_Pradesh — RRB merger history (context for RSETI sponsor naming; May-2025 Uttar Pradesh Gramin Bank merger)
17. https://pmajay.dosje.gov.in/ — PM-AJAY national portal (central predicate reference)

## Press / secondary (labelled in files)
18. https://timesofindia.indiatimes.com/city/lucknow/now-schemes-under-upscfdc-to-now-fall-under-pm-ajay/articleshow/92940343.cms — UPSCFDC schemes under PM-AJAY; GO 14-Jul-2022; Rs 50k grant; income-limit removal; cluster training
19. https://skillspedia.in/inviting-ebids-from-eligible-training-partners-for-conducting-skill-training-programme-under-the-centrally-sponsored-scheme-pradhan-mantri-anusuchit-jaati-abhyuday-yojana-pm-ajay/ — UP PM-AJAY RTD e-bid (1,650 SC beneficiaries)
20. https://iti.directory/ (Unnao/Sitapur/Kanpur Nagar/Varanasi listings) — aggregator with NCVT MIS codes — LIKELY/UNVERIFIED rows
21. https://onlineresultportal.wordpress.com/2014/05/17/govt-industrial-training-institute/ — DGET-era UP govt ITI list (2014, STALE) — LIKELY/UNVERIFIED
22. https://targetstudy.com/iti/52520/government-industrial-training-institute-iti-aliganj/ — ITI Aliganj Lucknow listing — LIKELY
23. https://www.facebook.com/p/Jan-Shikshan-Sansthan-LH-Lucknow-100070020677455/ — JSS Lucknow page (phone 0522-2472914, jss.gov.in-linked email) — LIKELY
24. https://jssaligarh.in/ — JSS Aligarh institutional site (MSDE-sponsored, est. 2006) — LIKELY
25. https://www.scribd.com/document/419809578/Jan-Shikshan-Sansthans — official-scheme JSS count document (UP = 47 JSSs, 2019) — context only
