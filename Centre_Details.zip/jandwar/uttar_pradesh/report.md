# Uttar Pradesh — JanDwar Data Pack Report

Retrieved: 2026-09-29 · Method: official rosters first (ICAR KVK node, PNB bank PDF, SLBC-UP booklets), then institute own-sites, then DGET-era/aggregator mirrors marked accordingly.

## 1. Deliverable 1 — centres.json (109 centres, 75/75 districts)

| Type | Count | Primary source |
|---|---|---|
| ICAR KVKs | 86 | icar.org.in/en/node/15021 — official ICAR state roster, ALL rows fetched (address, host org, sanction year; header "Uttar Pradesh (86)") |
| RSETIs (PNB-sponsored) | 7 | pnbindia.in official RSETI list PDF (director phones, landlines, emails) |
| Govt ITIs | 14 | institute own-sites (Gorakhpur Chargawan GR09000754, Varanasi Karaundi — CONFIRMED); iti.directory / DGET-era list mirrors (LIKELY/UNVERIFIED) |
| JSS | 2 | JSS Lucknow (official-linked page w/ phone), JSS Aligarh (own site) |

**Confidence: 11 CONFIRMED / 98 LIKELY / 0 UNVERIFIED** (script-validated; the 11th CONFIRMED is PNB RSETI Jhansi, contact-verified without street address).

- **KVK finding:** the official ICAR roster places a KVK in **74 of 75 districts** (all except Kanpur Nagar) plus 12 second-KVKs (2016–2020 wave) = 86 UP KVKs. This is the strongest district-saturation evidence of all five states.
- Kanpur Nagar covered by 3 govt ITIs (Ghatampur GU09001568 w/ phone; Kalyanpur; Mahila Lal Bangla).
- UP officially has **75 RSETIs — one per district** (SLBC-UP booklets 2015/16; last wave: Jhansi+Shamli by PNB, Sambhal+Hapur by then-Syndicate). **Gap acknowledged:** this pack lists only the 7 PNB-sponsored ones from PNB's own PDF; the other ~68 (SBI, Uttar Pradesh Gramin Bank/BoB legacy after the May-2025 RRB merger, Union, Indian, Central, BoI, Canara) are NOT individually listed because no official per-district UP table was fetchable — honestly reported, not padded. UP also has ~47 JSSs (2019 official-scheme count) of which only 2 captured — same reasoning.

## 2. Deliverable 2 — job_roles_additional.json (4 QPs)

| QP | Role | Level | Hours |
|---|---|---|---|
| NG-2.5-LT-00760-2023-V1-LSSC | Shoesmith (Cobbler) — PM Vishwakarma | 2.5 (fractional; numeric null + note) | **40** (15 toolkit + 23.5 ES + 1.5 feedback — verified on NQR file) |
| 2018/LT/DGT/02719 | Footwear Maker (CTS/ITI trade) | 3 | **2080** (verified on NQR title page) |
| LSS/Q5501 | Stitching Operator — Goods & Garments | 3 | null — PDF excerpt lacked totals |
| LSS/Q2501 | Stitching Operator (Footwear) | 4 | null |

**New sector token: `leather`** (LSSC) — maps to Agra (India's largest footwear hub) + Kanpur ("Leather City") + Unnao tanning fringe. Glass/ceramic (Firozabad) and carpet (Bhadohi–Mirzapur) QPs flagged in report as next-pass candidates; carpet already covered by existing `handloom_textile` tokens.

## 3. Deliverable 3 — districts.json

**75 districts — exact partition 75/0** (no district reorganisation in the project window). Name conventions (Ayodhya, Prayagraj, Bhadohi) noted; second-KVK districts listed.

## 4. Deliverable 4 — gia_funding_rules.json

- **UP is the one state where PM-AJAY = state schemes by name:** GoUP order of 14-Jul-2022 brought ALL UPSCFDC schemes under PM-AJAY; **income limit abolished** (was ₹56k), **≤₹2.5L priority**, self-employment **grant ₹10k→₹50k**, **cluster-based training + market linkage** (TOI report of the GO).
- **Official state training scheme (msme1connect.up.gov.in):** SC/ST Training Scheme — 4 months (1 theory + 3 practical), **post-training toolkit**, age 18–45, no literacy bar for non-technical trades / 8th pass for technical.
- **Live PM-AJAY RTD e-bid (Nov-2025):** 1,650 SC beneficiaries, 18+, ≤₹2.5L priority, Recruit-Train-Deploy mode.
- UP SDM Policy floors: ≥30% women (STEP-UP), SC/ST at least BPL-population-proportional, 3% PwD.
- Machine rule **UP-GIA-ELIG-001**; central predicate unchanged; rupee-per-trainee norm stated as not-found.

## 5. Deliverable 5 — district_economy.json (75 districts)

Officially anchored: Agra DIP (shoe cluster 5,000 units; carpet cluster 90 units/75,000 employed; Leather Park), Aligarh DIP (locks ~2,500 units, ~₹1,500 cr, 10,000 employed), MSME RAMP UP SIP 2025 (42 handloom clusters; Mirzapur–Bhadohi largest carpet cluster ~3.2M engaged; ODOP tables: Firozabad glass, Moradabad/Mahoba metal, Sant Kabir Nagar brass, Bahraich food, Jaunpur durrie), ODOP 75-district frame (Varanasi silk, Lucknow Chikankari, Kannauj attar, Saharanpur wood-carving). PM-AJAY priority districts flagged: Sonbhadra, Shravasti, Kaushambi, Chitrakoot (SC/tribal-share), plus the artisan belts (Varanasi, Mau, Bhadohi, Firozabad).

## 6. Stale / contradictory items

| Item | Issue |
|---|---|
| DGET-era UP ITI list (2014 blog mirror) | 12+ years stale; phones "as printed" — LIKELY/UNVERIFIED |
| iti.directory rows | aggregator (NCVT-code derived); LIKELY for code+phone rows, UNVERIFIED otherwise |
| UP "86 KVKs" | ICAR node counts 86 under UP while ATARI Kanpur zone shows 89 (zone includes 3 UK-side rows); roster used as-is, all 86 rows are UP districts |
| Kushinagar KVK pin | roster prints a Varanasi pin (221005) — flagged on record |
| RSETI coverage claim (75/75) | official SLBC booklets; per-district sponsor map not captured — gap stated |
| PNB Matki Jharoli double row | same institute listed twice on PNB PDF (RDC seat) — counted once |
| JSS count 47 vs 2 captured | 2019 scheme-count document vs fetched rows — gap stated |

## 7. Coverage statement

**109 centres across 75 of 75 districts.** Where I looked: ICAR (KVK node + KVK Knowledge Network), PNB (official RSETI PDF), SLBC-UP (coverage + sponsor history), institute own-sites (Gorakhpur, Karaundi, JSS Aligarh), iti.directory/DGET-mirrors (ITIs), UPSCFDC/PM-AJAY press + UP MSME portal (GIA), NQR/LSSC (QPs), dcmsme + RAMP SIP (economy). Gaps: 68 non-PNB RSETIs unlisted; 45 JSSs unlisted; only 14 of ~300 govt ITIs captured (UP DET portal unreachable — vppup.in not probed this pass); Firozabad/Bhadohi QP clusters deferred.
