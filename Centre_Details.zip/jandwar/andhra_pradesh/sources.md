# Andhra Pradesh Sources (all accessed 2026-09-29)

## Official — fetched directly
1. https://atari-hyderabad.org.in/kvks?lang=en — ICAR ATARI Zone X official KVK roster (23 AP KVKs: address, host org, sanction year) — KVK records
2. https://www.pendekantikvk.org/ — Pendekanti KVK Yagantipalle official site (address, phone 9440607424, Nandyal district)
3. https://www.kvkreddipalli-angrau.org/contact — KVK Reddipalli official contact (phones, location)
4. https://www.canarabank.bank.in/contact-details-of-rseti/rudseti/cbiit/ati — Canara Bank official statewise RSETI/RUDSETI list (AP rows: CB RSETI Kadapa, Kurnool, Sri Sathya Sai; RUDSETI Ongole, Anantapur — with mobiles/emails)
5. https://nirdpr.org.in/rseti/banks/documents/RSETI_Directory_2012.pdf — NIRDPR National RSETI Directory 2012 (official; STALE 14 yrs; Andhra Bank/SBH/ Syndicate RSETI addresses for Rajahmundry, Eluru, Machilipatnam, Venkatachalam, Chittoor, Guntur, Srikakulam, Vetapalem, Yemmiganur)
6. https://indianbank.bank.in/documents/d/guest/ibtrd_30082014 — Indian Bank IBTRD official doc (INDSETI Chittoor Kongareddypally + Machilipatnam Rustumbada, est. 2011; STALE)
7. https://www.slbcap.nic.in/pages/subcommitemeetings/04012024.pdf — SLBC-AP sub-committee minutes 04-01-2024 (11 RSETI-uncovered districts + lead-bank assignments; ATKUR RSETI→NTR; Vizag RSETI at Pendurthi) [fetched via search cache; direct fetch blocked]
8. https://dgt.gov.in/sites/default/files/2024-01/ModelITIAndhra.pdf — DGT Model ITI Andhra (Govt ITI Steel City Gajuwaka: principal L.B. Rajendra Prasad, 8886882161)
9. https://dgt.gov.in/sites/default/files/2023-12/10765_ITI_grades_phase_II_0.pdf + final%20grades_PhaseII.pdf — DGT official ITI grading records (govt ITI codes/names/districts)
10. https://www.nqr.gov.in/qualification/file/NSQC_AGR_Q4905_Freshwater%20Aquaculture%20Farmer_0.pdf — NSQC qualification file: AGR/Q4905 v3.0, Level 4, 390 h (90T+180P+60ES+60OJT)
11. https://www.nqr.gov.in/sites/default/files/Ornamental%20Fish%20Farmer-AGR_Q4910_v2.0.pdf — AGR/Q4910 Level 4 (hours not in excerpt)
12. https://www.nqr.gov.in/sites/default/files/Model%20Curriculum%20-%20Aquaculture%20Technical%20Supervisor.pdf — AGR/Q4903 Level 5
13. https://asci-india.com/pdf/Fishery%20hatchery%20production%20worker/QP_Fishery%20Hatchery%20Production%20Worker_Q4901.pdf — AGR/Q4901 v4.0, NSQC 18-02-2025, NQR ref QG-2.5-AG-03557-2025-V2-ASCI
14. https://konaseema.ap.gov.in/sc-corporation/ + https://krishna.ap.gov.in/sc-corporation/ + https://kadapa.ap.gov.in/sc-corporation/ — official district SC Society pages (eligibility, unit costs Rs 0.33-0.40 L, 100% subsidy, funding pattern)
15. https://spsnellore.ap.gov.in/district-industries-centre/ — official DIC Nellore (9 mega industries, contacts)
16. https://vizianagaram.ap.gov.in/dic/ — official DIC Vizianagaram (43 large/mega industries, sectors, contacts)
17. https://dcmsme.gov.in/dips/guntur%20profile_ap.pdf — MSME Brief Industrial Profile Guntur (turmeric/lime/zari/powerloom clusters)
18. https://dcmsme.gov.in/dips/amended%20chittoor%20dp%20march%202013.pdf — MSME Brief Industrial Profile Chittoor (fruit-processing, granite, Nagari powerloom, bus-body clusters; STALE 2013)
19. https://dcmsme.gov.in/old/dips/state_wise_profile_16-17/AP%20State%20profile%202016.pdf — AP State Profile 2016-17 (Rayadurg garments, Kopparthi engineering, Gandrajupalli silk; MSME counts; STALE)
20. https://dcmsme.gov.in/dips/state_wise_dips/APState%20Profile2014-15.pdf — AP State Profile 2014-15 (minerals, Budithi brass; STALE)
21. https://www.dcmsme.gov.in/schemes/Final_agenda%20_37th.pdf — MSE-CDP 37th Steering Committee agenda (Eluru gold, Dwaraka Tirumala ceramic, Vinukonda dal, Bethemeherla stone, Proddutur fly-ash clusters)
22. http://www.nlm.nic.in/tables/jss_li.htm — Ministry of Education legacy JSS table (7 AP JSSs with full contacts; UNDATED/STALE — LIKELY)
23. https://apit.ap.gov.in/?page_id=1762 — AP ITE&C Department (advanced-technology skilling)
24. https://x.com/rsetirjy — Union Bank RSETI Rajahmundry official bank handle (phone 8333814433, director, ex-ABIRD identity)
25. https://www.thehindu.com/news/national/andhra-pradesh/ap-to-have-26-districts-from-today/article65287440.ece — 26-district gazette (4 Apr 2022)
26. https://www.deccanchronicle.com/southern-states/andhra-pradesh/ap-cabinet-clears-formation-of-three-new-districts-total-to-rise-to-28-1926980 — 29-district gazette (Dec 2025): Markapuram, Madanapalle, Polavaram; mandal/division shifts
27. https://www.deccanchronicle.com/southern-states/andhra-pradesh/sc-corporation-launches-website-for-welfare-schemes-1978957 — AP SC Corporation portal launch + overseas skilling centres (Aug 2026)
28. https://www.pdicai.org/Docs/Andhra-Pradesh-State-Skill-Development-Corporation_68202195619287.pdf — APSSDC RFP: 23 Skill Colleges (design, Rs 20 cr cap, 1,920/yr)

## Secondary / UNVERIFIED (marked in centres.json)
29. https://hunnarbaaz.iti.directory/andhra-pradesh — ITI-directory aggregator (Bobbili, Etcherla-W, Dhone, Santhipuram, Pileru, CIFNET Vizag) — UNVERIFIED
30. https://www.collegesearch.in/articles/how-to-apply-for-andhra-pradesh-iti-admission — aggregator (Govt ITI-W Anantapur) — UNVERIFIED
31. https://ncvtiti.in/andhra-pradesh-iti-result/ — aggregator mirroring NCVT codes (Vakadu, Seethampeta, Nuzvid, TCP Centre) — LIKELY
32. https://pmajay.dosje.gov.in/ — PM-AJAY national portal (central predicate reference)
