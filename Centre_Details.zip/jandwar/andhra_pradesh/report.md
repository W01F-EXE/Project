# Andhra Pradesh — JanDwar Data Pack Report

Retrieved: 2026-09-29 · Method: official sources first (ATARI/ICAR, bank official pages, SLBC NIC minutes, NIRDPR, DGT PDFs, district NIC portals); search-cache mining where portals 500'd; aggregators only as UNVERIFIED.

## 1. Deliverable 1 — centres.json (83 centres, 27 of 29 districts)

| Type | Count | Primary source |
|---|---|---|
| ICAR KVKs | 23 | atari-hyderabad.org.in official Zone X roster (host, year, address); 3 KVK rows CONFIRMED via own-sites/kvk.icar.gov.in phones |
| RSETI / RUDSETI / INDSETI family | 18 | Canara Bank official statewise list (5, fetched directly); NIRDPR RSETI Directory 2012 (official, stale — 10); Indian Bank IBTRD doc (2, stale); SLBC-AP minutes (1 existence-grade: ATKUR→NTR) |
| Govt ITIs & other govt training centres | 35 | 28 from DGT official grading/Model-ITI PDFs (codes+names+districts; 1 with principal mobile); 7 aggregator-only rows marked UNVERIFIED |
| Jan Shikshan Sansthans | 7 | MoE legacy table nlm.nic.in (official but undated/stale — LIKELY) |

**Confidence: 10 CONFIRMED / 66 LIKELY / 7 UNVERIFIED.**

CONFIRMED = records where an official page was fetched directly with contact detail (Canara list, Pendekanti/Reddipalli/Utukur KVKs, DGT Model ITI PDF, Union RSETI Rajahmundry's bank-verified handle). LIKELY = official source exists but is stale (NIRDPR-2012, nlm.nic.in) or gives name+district without contacts (DGT grading records, ATARI roster without phones). UNVERIFIED = aggregator-only rows (hunnarbaaz/collegesearch ITI listings, CIFNET unit).

**Key finds:**
- **SLBC-AP official minutes (04-01-2024, slbcap.nic.in)** — the RSETI gap map: 11 uncovered districts with lead-bank assignments (Sri Sathya Sai→Canara [since opened], Parvathipuram Manyam & Annamayya→SBI, ASR/Anakapalli/Kakinada/Konaseema/Bapatla/Palnadu/Nandyal/WG→UBI); ATKUR RSETI mapped to NTR. This is judge-defensible evidence for the "without centre" districts.
- Canara's **CB RSETI Sri Sathya Sai (Puttaparthi)** exists on Canara's current official list — evidence a gap-listed RSETI opened between Jan-2024 and now.

**Gaps / where I looked:**
- iti.ap.gov.in (AP DET portal) would not fetch (same fragile-CMS pattern as TN/Kerala/KA); **no consolidated govt-ITI address/phone list found** — ITI rows therefore carry name+district (official DGT grading docs) but mostly null phones. AP has ~60-70 govt ITIs; 35 captured (28 official-grade).
- Union Bank's official AP RSETI list (9 claimed) exists at unionbankofindia.bank.in but the page returned HTTP 500 — rows were reconstructed from NIRDPR 2012 (stale) + the bank's official X handle (Rajahmundry: 8333814433).

## 2. Deliverable 2 — job_roles_additional.json (4 QPs)

| QP | Role | Level | Hours |
|---|---|---|---|
| AGR/Q4905 | Freshwater Aquaculture Farmer | 4 | **390** (verified: 90T+180P+60ES+60OJT, NQR NSQC file) |
| AGR/Q4910 | Ornamental Fish Farmer | 4 | null — PDF excerpt didn't print totals |
| AGR/Q4903 | Aquaculture Technical Supervisor (Biofloc/RAS) | 5 | null |
| AGR/Q4901 | Fishery Hatchery Production Worker | null (NQR code indicates level 2.5 — fractional, noted) | null |

- Sector token reused: **`fisheries`** (introduced in the Kerala pack). New SSC in the pack: **Agriculture Skill Council of India (ASCI)**.
- The aqua cluster (AGR/Q49xx) maps 1:1 to the Nellore–West Godavari–Krishna–Kakinada–Konaseema aqua belt — AP's biggest livelihood cluster.
- Handloom/silk QPs already in the project (TSC/Q2404 weaving fitter 450h; RSA silk QPs) cover Mangalagiri, Pedana kalamkari and Dharmavaram-Hindupur silk; not duplicated in this file.

## 3. Deliverable 3 — districts.json

**29 districts** (26 since Apr-2022; +Markapuram, +Madanapalle, +Polavaram via gazette of 31-Dec-2025). Partition: **27 with centre / 2 without** — Alluri Sitharama Raju and Dr. B.R. Ambedkar Konaseema (independently corroborated as RSETI-uncovered by official SLBC minutes). District remappings across the 2022/2025 reorganisations are noted on each affected centre record (12 remaps incl. Rajampet→YSR Kadapa, Markapur→Markapuram, Pileru→Madanapalle, Rampachodavaram→Polavaram).

## 4. Deliverable 4 — gia_funding_rules.json

- **Verified state layer (distinct from other states so far):** District SC Societies (SCSC) under APSCCF publish **actual unit costs**: Rs 0.33–0.40 lakh per trainee, 100% subsidy, three training buckets (high-end job-oriented / placement-oriented / general); eligibility SC, 18–50 y, ≤₹98k rural / ≤₹1.2L urban, SSC pass-or-fail, no outstanding loans (konaseema/krishna/kadapa ap.gov.in). Vintage caveat flagged (2018-19 print).
- **Fresh (Aug-2026):** AP SC Corporation overseas skilling — English ×6 centres (Vizag, Rajahmundry, Guntur, Nellore, Tirupati, Kurnool), German ×3, for Israel/Germany nursing placements.
- APSSDC: 23 planned Skill Colleges (₹20cr cap, 1,920 trainees/yr each), Siemens CoEs, Naipunyam job portal.
- Machine rule **AP-GIA-ELIG-001**; central PM-AJAY predicate unchanged (RPL 32–80h; STT 200–600h; EDP 80h; LTT 6–12mo; ≥70% placement; ≥30% women; no sector whitelist).

## 5. Deliverable 5 — district_economy.json (29 districts)

Officially anchored: Guntur DIP (Duggirala turmeric, Piduguralla lime, zari/powerloom 66,150 employed), Chittoor DIP (mango-pulp cluster 20,000 employed, granite, Nagari powerloom, bus-body Madanapalle), AP State Profile 2016-17 (Rayadurg garments, Kopparthi engineering, Gandrajupalli silk; Prakasam 23,548 MSMEs), 37th MSME agenda (Eluru gold, Dwaraka Tirumala ceramic, Vinukonda dal, Bethemeherla stone, Proddutur fly-ash), official DIC pages (Nellore mega-industries, Vizianagaram steel/pharma/cashew). **All DIPs are 2013-2017 vintage — stale, graded LIKELY.**

## 6. Stale / contradictory items

| Item | Issue |
|---|---|
| District count | 26 (2022) vs 29 (Dec-2025 gazette) — pack uses 29 with full remap notes; older official data still uses 26/13 |
| NIRDPR RSETI Directory 2012 | 14 years stale; sponsors renamed (Andhra Bank→Union 2020, SBH→SBI 2017) — noted per record |
| nlm.nic.in JSS table | undated, likely 2000s-era contacts — LIKELY, re-verify |
| MSME DIPs | 2013-2017 vintage |
| ICAR portal "AP 24 KVKs" vs ATARI roster 23 | 1-KVK discrepancy noted; ATARI per-KVK table used as primary |
| KVK Kalikiri district | Annamayya (2022-25) but near new Pileru division (Madanapalle) — inline re-verify note |
| collegesearch/hunnarbaaz ITI rows | aggregator-only, UNVERIFIED (women's ITI Anantapur, Bobbili, Etcherla-W, Dhone, Santhipuram, Pileru, CIFNET Vizag) |

## 7. Coverage statement

**83 centres across 27 of 29 districts; 2 districts (Alluri Sitharama Raju, Konaseema) have no captured centre — both officially confirmed uncovered by SLBC-AP (Jan-2024), which is itself the finding.** Here is where I looked: ATARI Zone X (KVKs), Canara Bank + NIRDPR + Indian Bank + SLBC (RSETIs), DGT grading/Model-ITI PDFs + AP DET portal (ITIs — portal unreachable), nlm.nic.in (JSS), MSME DIPs + DIC pages (economy), nqr.gov.in + ASCI (QPs), district NIC portals (GIA/SC Societies).
