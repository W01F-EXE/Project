# Sources — Tamil Nadu pack (all accessed 2026-09-29)

## Government ITIs (Deliverable 1)
| # | Source | Used for |
|---|---|---|
| 1 | https://skilltraining.tn.gov.in/chennai_reg.html | Govt ITIs — Chennai, Chengalpattu, Kancheepuram, Tiruvallur, Vellore, Ranipet, Tirupathur regions |
| 2 | https://www.skilltraining.tn.gov.in/DET/chennai_reg.html | DET variant page (Kunnam, Vellore ITI, Arakkonam placement note) |
| 3 | https://skilltraining.tn.gov.in/coimbatore_reg.html | Govt ITIs — Coimbatore, Nilgiris, Erode, Tiruppur |
| 4 | https://www.skilltraining.tn.gov.in/DET/coimbatore_reg.html | DET variant (ITI Karur, W-Coimbatore CUG, region counts) |
| 5 | https://skilltraining.tn.gov.in/salem_reg.html | Govt ITIs — Salem, Krishnagiri, Dharmapuri, Namakkal |
| 6 | https://skilltraining.tn.gov.in/madurai_reg.html | Govt ITIs — Madurai, Dindigul, Theni, Ramanathapuram, Sivaganga |
| 7 | https://skilltraining.tn.gov.in/trichy_reg.html | Govt ITIs — Tiruchirappalli, Thanjavur |
| 8 | https://www.skilltraining.tn.gov.in/DET/trichy_reg.html | DET variant (ITI Pudukkottai CUG) |
| 9 | https://skilltraining.tn.gov.in/tirunelveli_reg.html | Govt ITIs — Tirunelveli, Kanniyakumari, Tenkasi, Thoothukudi, Virudhunagar |
| 10 | https://skilltraining.tn.gov.in/villupuram_reg.html | Govt ITIs — Viluppuram, Kallakurichi, Cuddalore, Perambalur, Ariyalur |
| 11 | https://skilltrainingdet.in/coimbatore | Newer DET site (ITI Perur, Kangeyam) |
| 12 | https://skilltrainingdet.in/madurai | Newer DET site (ITI Thirupparankundram) |
| 13 | https://skilltrainingdet.in/trichy | Newer DET site (Kottur, Manachanallur, Needamangalam, Thirukkuvalai) |
| 14 | https://skilltrainingdet.in/tirunelveli | Newer DET site (ITI Eral, Kurukkalpatti) |
| 15 | https://skilltrainingdet.in/villupuram | Newer DET site (ITI Chengam, Cheyyar, ST Jamunamarathur) |
| 16 | https://skilltrainingdet.in/pdf/ep.pdf | DET contact PDF (landlines: Chidambaram, Radhapuram, Tenkasi, Tiruchendur, Sembodai, Thirukkuvalai, Aruppukottai, Virudhunagar; ITI place list incl. Nagapattinam) |
| 17 | https://pudukkottai.nic.in/industrial-training-institute/ | Govt ITI Pudukkottai (Thirugokarnam) address + landlines |
| 18 | https://www.govtitimadurai.com/ | Govt ITI Madurai address (K. Pudur, Madurai-625007) |
| 19 | https://tamil.abplive.com/education/mayiladuthurai-district-collector-announcement-government-iti-admission-tnn-261832 | Mayiladuthurai district: govt ITIs exist, 2026-27 admissions (news report of Collector's note) — UNVERIFIED record basis |

## TANUVAS — VUTRCs, FTCs, KVKs (Deliverable 1)
| # | Source | Used for |
|---|---|---|
| 20 | https://tanuvas.ac.in/contacts.php | Master list of all 20 VUTRCs + 3 FTCs + 4 TANUVAS KVKs (phones, emails) |
| 21 | https://tanuvas.ac.in/utrc_erode.php | VUTRC Erode full course list, fees, durations, entry requirement, address |
| 22 | https://tanuvas.ac.in/utrc_trichy.php | VUTRC Tiruchirappalli address, phone |
| 23 | https://tanuvas.ac.in/vutrc_vpm.php | VUTRC Villupuram address, phone, est. 2012 |
| 24 | https://tanuvas.ac.in/vutrc_tnj.php | VUTRC Thanjavur address, phone |
| 25 | https://www.tanuvas.ac.in/kvks.php | The 4 TANUVAS-hosted KVKs (Kattupakkam, Kundrakudi, Namakkal, Villupuram II) |

## KVKs — TNAU & NGO-hosted (Deliverable 1)
| # | Source | Used for |
|---|---|---|
| 26 | https://tnau.ac.in/site/dee/kvks-list/ | Current official TNAU KVK list (15 KVKs, est. years incl. Tiruppur 2019, Ooty 2021) |
| 27 | https://tnau.ac.in/site/kvk-trichy/contact-us/ | KVK Sirugamani address + phones |
| 28 | https://agritech.tnau.ac.in/pdf/univ_tel_dir.pdf | TNAU telephone directory (undated PDF) — KVK addresses/phones (LIKELY stale) |
| 29 | https://agritech.tnau.ac.in/pdf/univ_tel_dir_16.06.17.pdf | Older TNAU directory (2016-17 vintage) — Cuddalore/Pudukkottai/Madurai/Dindigul/Karur KVK rows |
| 30 | https://agritech.tnau.ac.in/doee/KVK.html and .../KVK_list.html | Older (©2017) TNAU KVK index — used only to cross-check names |
| 31 | http://krishnagirikvk.org/ | KVK Krishnagiri address + phones (official KVK site) |
| 32 | https://kvknagapattinam.co.in/wp-content/uploads/2021/12/Annual-Progress-Report-2014-15.pdf | KVK Sikkal/Nagapattinam address (2014-15 report — flagged stale) |

## RSETIs (Deliverable 1)
| # | Source | Used for |
|---|---|---|
| 33 | https://www.canarabank.bank.in/contact-details-of-rseti/rudseti/cbiit/ati | Canara Bank RSETIs TN (Dindigul, Erode, Ooty, Pudupudur, Theni, Karaikudi, Tiruppur) + RUDSETI Madurai — addresses, mobiles |
| 34 | https://www.canarabank.bank.in/canara-bank-centenary-rural-development-trust-cbcrdt- | Dr. Ambedkar SETI, Pudupudur (existence) |
| 35 | https://www.iob.bank.in/en/rseti | IOB RSETIs TN (Karur, Perambalur, Ramanathapuram, Thanjavur, Tirunelveli, Trichy, Tenkasi, Mayiladuthurai) — via search cache of this page; script-rendered page itself |
| 36 | https://nirdpr.org.in/rseti/ + 2012/2015 NIRDPR directories | Checked for master list — directories stale (2012/2015), portal not machine-readable; **gap noted** |

## Jan Shikshan Sansthan (Deliverable 1)
| # | Source | Used for |
|---|---|---|
| 37 | https://jssmadurai.blogspot.com/ | JSS Madurai address/courses — **2007, stale, UNVERIFIED** |
| 38 | https://www.facebook.com/JSSTVR23/ | JSS Thiruvarur existence — UNVERIFIED |
| 39 | https://youthpower.in/institution/tamil-nadu/nilgiris/jss | JSS Nilgiris description — aggregator, UNVERIFIED |
| 40 | https://skillspedia.in/wp-content/uploads/2022/05/SKILLSPEDIA-EOI-JAN-SHIKSHAN-SANSTHAN-JSS.pdf | MSDE 2022 EOI: 11 TN districts identified for new JSSs (report only, not centre records) |
| 41 | https://www.msde.gov.in/static/uploads/2024/02/a58c37c42f8511ec0cadde5f64b4cce0.pdf | MSDE AR 2023-24 (JSS context) |

## PM-AJAY rules (Deliverable 4)
| # | Source | Used for |
|---|---|---|
| 42 | https://pmajay.dosje.gov.in/Writereaddata/Guidelines_PM-Ajay_July2020.pdf | SCA-SCSP consolidated guidelines (July 2020): Annexure-I activity list, Annexure-II skill programmes (types/durations), NSQF compliance, CCN cost cap, 70% placement, agencies incl. NSFDC Appendix-I |
| 43 | https://pmajay.dosje.gov.in/Writereaddata/PM-Ajay.pdf | PM-AJAY AAP circular ('Grant to States' component, FY 2021-22): merger structure, ≥10% skill share, RPL 32-80h, long-term 6mo+, CCN/NCVT cap, 70% placement |
| 44 | https://pmajay.dosje.gov.in/public/uploads/pac/81qMsTZ9s8.pdf | PAC minutes 2023 (enforcement of 10%/30% shares; states must name trades + training partners) |
| 45 | https://tahdco.com/pmajay-scheme.php | TAHDCO PM-AJAY page (TN subsidy norms: 50% or Rs 50,000; income ≤ Rs 3 lakh) |
| 46 | https://tahdco.com/ | TAHDCO live skill catalogue (de facto TN trade list) |
| 47 | https://tiruvallur.nic.in/the-tamil-nadu-adi-dravidar-housing-and-development-corporation-tahdco-will-provide-training-to-adi-dravidars-and-tribals/ | TAHDCO aviation training notice (Jan 2025) |

## NSQF QPs (Deliverable 2) — National Qualification Register unless noted
| # | Source | QP |
|---|---|---|
| 48 | https://hsdm.org.in/doc/qualification_packs/LSS_Q2301_v1.0.pdf | LSS/Q2301 Cutter-Footwear (L4) |
| 49 | https://www.nqr.gov.in/sites/default/files/Annexure%201_LSS_Q5501_v2.0_Stitcher_Goods&Garments.pdf | LSS/Q5501 Stitcher-G&G (L3) |
| 50 | https://www.nqr.gov.in/qualification/file/QF%20-%20Automotive%20Detailer%20Technician.pdf | ASC/Q1433 (L4) |
| 51 | https://www.nqr.gov.in/sites/default/files/QF%20-%20Automotive%20Machining%20Trainer.pdf | ASC/Q3511 (L5) |
| 52 | https://www.nqr.gov.in/qualification/file/Automotive%20Electric%20Vehicle%20BSS%20(Battery%20Swapping%20Syste%20(1).pdf | ASC/Q8314 |
| 53 | https://nqr.gov.in/sites/default/files/QP_HSSQ5101_General%20Duty%20Assistant_v2.0.pdf | HSS/Q5101 GDA |
| 54 | https://nqr.gov.in/sites/default/files/Annexure%203%20GDA%20Advanced%20MC%20final.pdf | HSS/Q5103 GDA-Advanced (model curriculum) |
| 55 | https://nqr.gov.in/sites/default/files/NSQF-%20Medical%20Laboratory%20Technician_0.pdf | HSS/Q0301 MLT |
| 56 | https://nqr.gov.in/sites/default/files/Q%20File%20Panchakarma%20Technician..pdf | HSS/Q3601 |

## Districts & district economy (Deliverables 3 & 5)
| # | Source | Used for |
|---|---|---|
| 57 | https://www.tn.gov.in/district_list.php | Official 38-district list & spellings (Kanniyakumari, Sivaganga, Viluppuram, Tirupathur, The Nilgiris) |
| 58 | https://dcmsme.gov.in/dips/2016-17/DIP.SALEM.2015.16.1.pdf | Salem economy (silver jewellery, textiles, steel) — 2015-16, official |
| 59 | https://dcmsme.gov.in/dips/2016-17/DIP.VILLUPURAM.2015.16.pdf | Viluppuram economy (sugar, sago, ginning, wood carving) — official |
| 60 | https://msmedi-chennai.gov.in/GARMS_Admin/basictools/images/DIPSReport/Tiruvannamalai.pdf | Tiruvannamalai economy (scent/floriculture, rice, khadi) — official |
| 61 | https://dcmsme.gov.in/dips/IPS%20coimbatore%202012_t.pdf | Coimbatore economy (textiles, cotton) — 2012-13, official |
| 62 | https://dcmsme.gov.in/old/dips/ips%20erode%202012_tn.pdf | Erode economy (garment & coir clusters) — official |
| 63 | https://dcmsme.gov.in/old/dips/IPS%20Madurai%202012_tr.pdf | Madurai economy (agri implements, garments, granite, dairy) — official |

**Caveat repeated:** dcmsme/msmedi profile PDFs are 2012–2016 vintage — official but old; do not present cluster sizes as current.
