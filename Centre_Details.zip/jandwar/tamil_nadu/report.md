# JanDwar — Tamil Nadu data pack (PM-AJAY GIA, PS 26097)

**State:** Tamil Nadu (38 districts). **Research date:** 2026-09-29. **Files:** `centres.json`, `job_roles_additional.json`, `districts.json`, `gia_funding_rules.json`, `district_economy.json`, `sources.md`.

---

## The honest coverage number

**180 centres verified across all 38 of 38 districts**, broken down as:

| Type | Records | Quality |
|---|---|---|
| Government ITIs (DET, 7 regions) | 113 | mostly CONFIRMED — name, district, principal CUG phone from official DET regional tables |
| TANUVAS VUTRCs (vet/dairy self-employment) | 20 | 4 CONFIRMED with full course/fee/address data; 16 LIKELY (phone+email confirmed, address null) |
| TANUVAS Farmers Training Centres | 3 | LIKELY |
| KVKs (TNAU 15 + TANUVAS 4 + NGO-hosted 5) | 24 | existence CONFIRMED from university lists; contact details mixed, several stale |
| RSETIs (Canara 7 + RUDSETI 1 + IOB 8) | 16 | Canara CONFIRMED; IOB LIKELY (via cached official page) |
| Dr. Ambedkar SETI, Coimbatore | 1 | LIKELY (existence only) |
| Jan Shikshan Sansthans | 3 | UNVERIFIED — see below |

Confidence totals: **114 CONFIRMED, 4 CONFIRMED-existence, 58 LIKELY, 4 UNVERIFIED.**

**What is NOT in this pack (do not claim it):**
- **PMKVY/empanelled private training centres** — Skill India Digital (skillindiadigital.gov.in) is a JS app that the scraper cannot query, and no machine-readable state TC list was found. This is the biggest known gap. Judges can be shown SIDH's "Training Centres, State = Tamil Nadu" view live.
- **~15–20 RSETIs**: TN has roughly one RSETI per district (≈33–38). I verified 17 (banks publish them one bank at a time; SBI and Indian Bank RSETI pages did not surface in this pass, and NIRDPR's national RSETI directory PDFs are from 2012/2015 — stale). Districts still likely to have an unlisted RSETI: Chennai, Chengalpattu, Kancheepuram, Tiruvallur, Vellore, Ranipet, Tirupathur, Cuddalore, Dharmapuri, Krishnagiri, Pudukkottai, Kallakurichi, Viluppuram, Kanniyakumari, Thoothukudi, Virudhunagar, Nagapattinam, The Nilgiris (some covered by neighbours).
- **Viluppuram district's remaining 3 govt ITIs**: the DET region summary says 4 govt ITIs in Viluppuram district; only Tindivanam was named on the pages accessed.
- **TAHDCO training centres**: TAHDCO (the SC-welfare corporation) runs courses through partners announced per-tender (CIPET plastics, textile, solar, CNC, cosmetology, aviation, IIT-M data science). It publishes courses, not a centre directory. Cite tahdco.com for the catalogue instead.
- **Per-ITI trade lists**: DET regional tables give name/district/principal phone but not trades. Pull trade lists from NCVT MIS (ncvtmis.gov.in) per ITI code before launch.

**Where I looked and drew blanks:** jss.gov.in now redirects to Skill India Digital (no static list); the MSDE 2022 EOI lists 11 TN districts where new JSSs were being added (Ramanathapuram, Cuddalore, Kanniyakumari, Salem, Tenkasi, Thanjavur, The Nilgiris, Theni, Tirunelveli, Thoothukudi, Vellore) — treat these as "JSS present or sanctioned, address unknown". kvk.icar.gov.in was not machine-readable in this pass; KVK data was assembled from TNAU/TANUVAS official lists instead.

---

## Stale or contradictory things I found (flagged, not silently used)

1. **Two DET websites disagree.** `skilltraining.tn.gov.in` (older) vs `skilltrainingdet.in` (current). Different principals, CUG numbers and even ITI rosters (e.g., ITI Arakkonam under Vellore vs Ranipet; Kangeyam/Perur/Eral/Kurukkalpatti/Chengam/Cheyyar only on the newer site). Records cite which page each field came from; principals rotate, so treat all personal-name/phone rows as "call before you send someone".
2. **TANUVAS contacts page** lists VUTRC "Dharmapur" (sic) and phone digits with typos (e.g., Namakkal KVK "0428-2666144"); I published digits as printed with a note.
3. **IOB RSETI page** is script-rendered; its search-cache had two merged rows (Ramanathapuram director ↔ Thanjavur address). Address for Ramanathapuram and phone for Thanjavur are therefore `null` on purpose.
4. **JSS Madurai** data is from a 2007 institutional profile — 19 years old. Marked UNVERIFIED.
5. **TNAU's KVK directory PDF** has no visible date (2016–17 vintage); phones are LIKELY-stale. The 2017 agritech KVK list is also superseded by the current tnau.ac.in list (which adds Tiruppur 2019, Ooty 2021).
6. **ITI Tiruchirappalli Prison** exists on the DET list — decide whether the app should ever route a user there.
7. **Mayiladuthurai** has government ITIs per the Collector's May-2026 admission notice (Tamil press), but no name/address/phone was published — kept as one UNVERIFIED record so the district isn't falsely shown empty.

---

## Deliverable 2 — NSQF gaps for Tamil Nadu

Your 7 SSCs (ASCI, MESC, CSDCI, TSC, FICSI, AMHSSC, IASC) miss the sectors TN actually lives on. Priority order for the state:

1. **Leather (LSSC)** — Chennai–Ranipet–Vaniyambadi–Ambur–Dindigul belt; one of TN's largest SC employers. QPs delivered: `LSS/Q2301` (Cutter–Footwear, L4), `LSS/Q5501` (Stitcher–Goods & Garments, L3).
2. **Automotive (ASDC)** — Chennai "Detroit of India", Hosur (TVS/EV), Oragadam, bus-body building in Karur. QPs delivered: `ASC/Q1433` (L4), `ASC/Q3511` (L5 trainer), `ASC/Q8314` (EV battery-swap; level null).
3. **Healthcare (HSSC)** — Chennai/Vellore/Madurai/Trichy destination-hospital economies; GDA-type roles are the classic entry point for SC women. QPs delivered: `HSS/Q5101`, `HSS/Q5103`, `HSS/Q0301`, `HSS/Q3601` (levels/hours null where the NQR excerpt didn't print them — read the full QF PDFs before trusting estimates).
4. **Tourism & Hospitality (THSC)** — TN is India's top domestic-tourism state; no QP verified this pass (flagged).
5. **Logistics (LSC)** — ports at Chennai/Ennore/Kattupalli/Tuticorin + Namakkal trucking; no QP verified (flagged).
6. **Retail (RASCI), Gems & Jewellery (GJSCI — Salem silver, Coimbatore/Trichy/Vellore jewellery), IT-ITeS (SSC NASSCOM), Handicrafts (HHSC — Thanjavur bronzes, Swamimalai), Fisheries (ASCI already holds FIS-series QPs — check whether your 516 ASCI rows include them)** — all flagged as gaps, none verified this pass.

**Notional hours:** only verifiable where the NQR/SSC excerpt prints them; everything unverified is `null` with a note. Do not let the app estimate course duration from a guessed hours value.

**New sector tokens introduced:** `leather`, `automotive`, `healthcare`, `tourism_hospitality`, `logistics`, `retail`, `gems_jewellery`, `it_ites`, `handicrafts`, `fisheries`, `renewable_energy`, `beauty_wellness`, `banking_financial_services` (the last three used in gia_funding_rules/district_economy vocabularies). All others reuse your tokens.

---

## Deliverable 4 — what PM-AJAY GIA actually funds (summary)

Full prose + machine rule are in `gia_funding_rules.json`. Headlines, with citations:

- **No trade/QP whitelist exists.** Eligibility is by programme type + an *illustrative* Annexure-I activity list. NSQF compliance is required generically; **no NSQF level range is prescribed** — your app can't derive a level filter from the guidelines, so say so.
- **Programme types & durations:** RPL 32–80 h (≤1 month); Short-term 200–600 h (≤5 months, or per QP/NOS); EDP 80 h; Long-term 6–12 months (or per regulator).
- **Money rules:** training cost capped by **MSDE Common Cost Norms/NCVT** (separate doc — not reproduced; get it before quoting rupee figures); milestone payments; ≥10% of release must fund skilling; ≥70% placement (wage+self) required, ≥70% of long-term placed in wage jobs; ≥30% women; 5% of SCA for disabled persons' schemes.
- **Executing agencies:** SSDMs and their TPs, SSC-affiliated TIs, **NSFDC's Appendix-I list of institutes** (printed in the guidelines PDF — a ready-made partner list for JanDwar), and others with a 1,000-trainees/3-years/70%-placement track record; long-term training only in centres the TP owns (no franchises).
- **Tamil Nadu:** implemented by **TAHDCO** under the ADW Department. TAHDCO's PM-AJAY page: IGS subsidy = 50% of project cost or **Rs 50,000** (whichever lower), SC, 18–55, family income ≤ Rs 3 lakh. **No state-approved trade list under PM-AJAY was found**; TAHDCO's live skill catalogue is the de facto list.
- Your current whitelist (agriculture, food_processing, construction, handloom_textile) is **too narrow** — Annexure-I explicitly covers fisheries, dairy/animal husbandry, leather, healthcare, IT/ITeS, retail, gems & jewellery, beauty, plumbing, auto repair, media. Replace it with the `eligible_sectors_from_annexure1` list in the JSON, labelled "derived from PM-AJAY SCA-SCSP Annexure-I (illustrative)".

---

## Deliverable 5 — method & honesty

`district_economy.json` covers all 38 districts. Six notes (Erode, Salem, Viluppuram, Coimbatore, Madurai, Tiruvannamalai) cite an official MSME Brief Industrial Profile PDF I actually retrieved — **all are 2012–2016 vintage**; say so on slides. The other 32 are LIKELY-flagged general documented knowledge with `source: null`; before the demo, batch-download the remaining `dcmsme.gov.in` District Industrial Profiles (the series I linked exists for other districts — file names vary, so I did not invent URLs). Recommended upgrades: TN Economic Appraisal (DES), TNSRLM/DDU-GKY district data, Census 2011 occupational tables.

## Districts (Deliverable 3)

Official spellings follow tn.gov.in's district list: **Kanniyakumari** (not Kanyakumari), **Sivaganga** (not Sivagangai), **Viluppuram** (not Villupuram), **Tirupathur** (not Tirupattur), **The Nilgiris**. Reorganisations: 2019 carved Chengalpattu, Kallakurichi, Tenkasi, Tirupathur, Ranipet; 2020 carved Mayiladuthurai → 38 districts. Every district has ≥1 centre record — but Mayiladuthurai's only has an UNVERIFIED ITI entry plus an IOB RSETI, so treat it as the weakest cell. `districts.json` was generated from `centres.json` itself, so the with/without partition is exact by construction.

## Next state

Say "next" and I'll run **Kerala** (14 districts — small enough to go truly deep: Kudumbashree/CDS networks + RSETIs + ITIs + KVKs + fisheries).
