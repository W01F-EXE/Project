# Sources — Kerala pack (all accessed 2026-09-29)

Note: det.kerala.gov.in returned HTTP 500 to direct fetches; its official tables were read via search-engine caches of the official pages (content quoted as published).

## Government ITIs (Deliverable 1)
| # | Source | Used for |
|---|---|---|
| 1 | https://det.kerala.gov.in/?p=1022&lang=en | "Govt ITIs as on 01.08.2025" — names + phones, all districts (TVM, Kollam, PTA, KTM, IDK, WYD, KSD, ALP, KZD blocks captured) |
| 2 | https://det.kerala.gov.in/?p=2417&lang=en | "Address of ITIs" — full addresses + phones (Kollam, Kottayam, Alappuzha, Malappuram, Wayanad, Kannur, Ernakulam, Thrissur, Kozhikode blocks) |
| 3 | https://det.kerala.gov.in/index.php/83-about-us?start=8 | Affiliated-trades list page — ITI(W) Malampuzha phone |
| 4 | https://det.kerala.gov.in/images/mes/vtpins.pdf | VTP/ITI list PDF (undated) — SCDD ITIs (Erumely, Kurichy, Madhuraveli, Madappally, Kulakkada) |
| 5 | https://palakkad.nic.in/en/public-utility/govt-iti/ | Govt ITI Malampuzha address + phone (district administration) |
| 6 | https://itinadathara.kerala.gov.in/ | Govt ITI (SCDD) Nadathara — own government site (address, phones) |
| 7 | http://www.womenitithallakkanam.kerala.gov.in/about-us/institute/contact | Govt ITI Idukki-Kanjikuzhy — own government site |
| 8 | https://itiadmissions.kerala.gov.in/iti.php?id=48 | PTCM Govt ITI Pallickathodu (state ITI-admission portal) |

## ASAP Kerala Community Skill Parks (Deliverable 1)
| # | Source | Used for |
|---|---|---|
| 9 | https://asapkerala.gov.in/training_center/csp-kasaragod/ | CSP Kasaragod (address, phone, drone + Dharppanam courses) |
| 10 | https://asapkerala.gov.in/training_center/csp-kulakkada/ | CSP Kulakkada, Kollam |
| 11 | https://asapkerala.gov.in/training_center/csp-cheriyakalavoor/ | CSP Cheriya Kalavoor, Alappuzha |
| 12 | https://asapkerala.gov.in/training_center/csp-kunnamkulam/ | CSP Kunnamkulam, Thrissur |
| 13 | https://asapkerala.gov.in/training_center/csp-vizhinjam/ | CSP Vizhinjam, TVM (courses incl. GDA, marine structural fitter) |
| 14 | https://asapkerala.gov.in/training_center/csp-lakkidi/ | CSP Lakkidi, Palakkad |
| 15 | https://asapkerala.gov.in/training_center/csp-chathannur/ | CSP Chathannur, Palakkad (ESAF; drone/AR-VR/jewellery/beauty) |
| 16 | https://asapkerala.gov.in/training_center/csp-pandikkad/ | CSP Pandikkad, Malappuram |
| 17 | https://skills.knowledgemission.kerala.gov.in/local/marketplace/product_details.php?id=948 | Govt Knowledge Mission skills marketplace — CSP Kazhakoottam, Kunnamthanam, Kalamassery, ASAP SDC Kozhikode (names/districts) |

## RSETIs (Deliverable 1)
| # | Source | Used for |
|---|---|---|
| 18 | https://www.cbrsetithrissur.in/ | CB RSETI Thrissur (own site — CONFIRMED) |
| 19 | https://www.freejobalerts.co.in/training/free-job-oriented-training/ | Canara Bank RSETI Kottarakkara phone (aggregator — UNVERIFIED) |
| 20 | https://lsgkerala.gov.in/en/node?page=21 | LSGD note: Kerala RSETIs work with Kudumbashree; one RSETI per district context |
| 21 | https://www.unionbankofindia.bank.in/en/details/rural-self-employment-training-institutes-rsetis-sponsored-by-bank | Union Bank sponsors 3 Kerala RSETIs (count only; names not obtained — gap noted) |
| 22 | https://sbi.bank.in/web/agri-rural/rural/rural-self-employment-training-institutes-rsetis | SBI RSETI programme context (no Kerala list published on page) |

## KVKs (Deliverable 1)
| # | Source | Used for |
|---|---|---|
| 23 | https://icar.org.in/en/node/15050 | ICAR official Kerala KVK list — all 14 KVKs, hosts, addresses |
| 24 | https://kvkkasaragod.in/page/about | KVK Kasaragod (address, phone, 14-KVK/hosts summary) |
| 25 | https://kvkpalakkad.kau.in/ | KVK Palakkad (address, phone) |
| 26 | https://kau.in/institution/krishi-vigyan-kendra-malappuram | KVK Malappuram (address, phone, coordinator) |
| 27 | https://agritech.tnau.ac.in/kvk/kvkindia/kerala.pdf | Older aggregated Kerala KVK contact sheet (phones — flagged stale) |

## JSS (Deliverable 1)
| # | Source | Used for |
|---|---|---|
| 28 | https://src.kerala.gov.in/index.php?option=com_content&view=article&id=81&Itemid=92 | State Resource Centre (Kerala) JSS listing — 9 JSS addresses (page undated, LIKELY) |
| 29 | https://thecsruniverse.com/organisation/jan-shikshan-sansthan-thrissur | JSS Thrissur profile (est. 2000, beneficiary history) |

## Coir Board / KVASU / CIFNET (Deliverable 1)
| # | Source | Used for |
|---|---|---|
| 30 | http://www.ccriindia.org/home_page_of_nctdc.html | NCT&DC Kalavoor: NSQF L3 coir courses, address, phone |
| 31 | https://www.ccriindia.org/contact_us.html | Coir Board institute contacts (NCT&DC phone cross-check) |
| 32 | https://english.mathrubhumi.com/education/news/coir-board-training-certificate-diploma-courses-application-mfxzrjf0 | Jan-2026 admission notice: NSQF L3 cert, 1-yr diploma, SC/ST quota, hostel, stipend |
| 33 | https://nqr.gov.in/sites/default/files/3.Annexure%202%20Training%20Manual%20%20of%20coir%20Board(.pdf | Coir Board training manual (NCT&DC history/courses) |
| 34 | https://www.kvasu.ac.in/college/more/4 | VKIDFT Mannuthy (dairy/food tech, farmer training, address, phone) |
| 35 | https://www.kvasu.ac.in/cas-in-poultry-science--mannuthy-1 | CAS Poultry Science Mannuthy (farmer training record, phone) |
| 36 | https://cifnet.gov.in/index.php/content/index/regular-courses | CIFNET Kochi regular courses (BFSc NS, DGT trades) |

## PM-AJAY / state rules (Deliverable 4)
| # | Source | Used for |
|---|---|---|
| 37 | https://pmajay.dosje.gov.in/Writereaddata/Guidelines_PM-Ajay_July2020.pdf | Central skill guidelines (Annexure I & II) |
| 38 | https://pmajay.dosje.gov.in/Writereaddata/PM-Ajay.pdf | AAP circular (programme types, shares, CCN cap) |
| 39 | https://scdd.kerala.gov.in/index.php/schemes/planning | SCDD SCSP 2022-23: Rs 4,900 lakh skill outlay, MRS finishing schools, PETCs |
| 40 | https://duk.ac.in/applications-invited-for-skill-development-programs-in-association-with-scheduled-caste-department/ | Digital University Kerala PM-AJAY 1-yr residential programmes |

## NSQF QPs (Deliverable 2) — National Qualification Register
| # | Source | QP |
|---|---|---|
| 41 | https://www.nqr.gov.in/qualification/file/Q-file_Fish%20Seed%20Grower%20v4.pdf | QG-04-AG-03236-2024-V2-ASCI Fish Seed Grower (L4) |
| 42 | https://www.nqr.gov.in/qualification/file/Q%20File-Fisheries%20Post%20Harvest%20Supervisor.pdf | QG-05-AG-01263-2023-V1-CUTM Fisheries Post Harvest Supervisor (L5) |
| 43 | https://www.nqr.gov.in/sites/default/files/Ornamental%20Fish%20Farmer-AGR_Q4910_v2.0.pdf | AGR/Q4910 Ornamental Fish Farmer |
| 44 | https://nqr.gov.in/sites/default/files/Annexure%202_Food%20Delivery%20Associate_THC_Q2902_v2.0_0.pdf | THC/Q2902 (L3) |
| 45 | https://nqr.gov.in/sites/default/files/Annexure%202_Street%20Food%20Vendor-%20Standalone_THC_Q3008_v2.0.pdf | THC/Q3008 (L4, basic-literacy entry) |
| 46 | https://nqr.gov.in/sites/default/files/Annexure%203_MC_THC_Q0102_Front%20Office%20Associate.pdf | THC/Q0102 (L4) |

## Districts & district economy (Deliverables 3 & 5)
| # | Source | Used for |
|---|---|---|
| 47 | Kerala government district listings (det.kerala.gov.in district menus; district e-governance portals) | 14-district set and spellings |
| 48 | https://dcmsme.gov.in/dips/DIPKANNUR.pdf | Kannur economy (MSME profile — urbanisation, plywood, Keltron) |
| 49 | https://dcmsme.gov.in/dips/Dt%20%20profile-%20KOTTAYAM-WORKING.pdf | Kottayam economy (MSME profile — rubber clusters, footwear vendorisation, ethnic food, screwpine) |
