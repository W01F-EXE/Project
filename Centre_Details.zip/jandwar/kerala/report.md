# JanDwar — Kerala data pack (PM-AJAY GIA, PS 26097)

**State:** Kerala (14 districts). **Research date:** 2026-09-29. **Files:** `centres.json`, `job_roles_additional.json`, `districts.json`, `gia_funding_rules.json`, `district_economy.json`, `sources.md`.

---

## The honest coverage number

**146 centres verified across all 14 of 14 districts (99 CONFIRMED / 45 LIKELY / 2 UNVERIFIED):**

| Type | Records | Quality |
|---|---|---|
| Government ITIs + BTC + AVTS (Kerala Industrial Training Dept) | 112 | name/district/phone from the official DET lists ("Govt ITIs as on 01.08.2025" + "Address of ITIs"); addresses for ~70% of them |
| Govt ITIs run by the Scheduled Caste Development Dept (SCDD) | 6 (included above) | gold for JanDwar — SC-department-run ITIs in Kottayam/Kollam/Thrissur; mostly from an undated DET VTP PDF, flagged |
| ASAP Kerala Community Skill Parks / SDCs | 12 | official asapkerala.gov.in pages with addresses + centre-head mobiles; course lists included where published |
| Krishi Vigyan Kendras | 14 (one per district) | hosts confirmed on ICAR's official list; phones from official KAU/KVK pages (4 CONFIRMED) or an older aggregated sheet (LIKELY) |
| Jan Shikshan Sansthans | 8 | addresses from the State Resource Centre (Kerala) — official but undated page, LIKELY |
| RSETIs | 2 | Thrissur CONFIRMED (own website); Kottarakkara UNVERIFIED (aggregator) |
| Coir Board NCT&DC, Alappuzha | 1 | CONFIRMED — NSQF L3 coir technology, 20% SC/ST quota, women's hostel, stipend |
| KVASU dairy/poultry institutes (Mannuthy) | 2 | LIKELY — official KVASU pages |
| CIFNET Kochi (fishing-vessel trades) | 1 | courses CONFIRMED from official site; address null this pass |

**What is NOT in this pack (do not claim it):**
- **The other ~12 district RSETIs.** Kerala has one RSETI per district (run with Kudumbashree as the NRLM anchor; lead banks vary — Canara, SBI, Union ×3, Indian Overseas…). Only Thrissur (own site) and Kottarakkara (aggregator) were individually verified this pass. Banks publish RSETI contacts one bank at a time and most Kerala RSETI pages did not surface.
- **PMKVY/empanelled private TCs** — Skill India Digital remains unscrapable; same gap as TN.
- **KASE-empanelled training provider directory** — not machine-readable in this pass; ASAP CSPs are the state-flagship public venues I could verify.
- **Kudumbashree-run training centres** — Kerala's largest women's livelihood network; its training offerings are per-CDS and not published as a centre directory. For the app, treat Kudumbashree as a mobilisation partner, not a venue list.
- **ITI trade lists** — DET publishes affiliation orders per ITI (download links on the same page); batch-fetch before launch.

**Caveats that matter:** the DET website rejected direct fetches (HTTP 500), so its official tables were read via search-engine caches of the official pages — content is official, but note it in methodology. Several DET phone fields have printing defects (Kodombeloor ITI: 9-digit number; ITI(W) Kozhikode: two official pages disagree on one digit) — preserved with flags rather than silently "fixed". The State Resource Centre JSS page and the DET VTP (SCDD ITIs) PDF carry no visible dates.

---

## Stale or contradictory things found (flagged, not silently used)

1. **ITI Kalamassery's phone on the DET address page (0486-2238038) is byte-identical to Govt ITI Kanjikuzhi's verified number** — almost certainly a DET typo. Kept with a caution note.
2. **ITI(W) Kozhikode**: 0495-2373976 (old ITD list) vs 0495-2372976 (address page). Both published.
3. **STD prefixes truncated** by DET on several numbers (Nilambur 0493-…, Kalpetta 0493-…, Desamangalam 0488-…) — published as printed with the likely correct prefix noted.
4. **Govt ITI (SCDD) Madappally** — the VTP PDF's district column says Kottayam, but a Madappally town also exists in Kozhikode. Marked UNVERIFIED for district.
5. **Two address forms for JSS Thrissur** (Pallipuram vs Kodungalloor) across official/CSR sources — both shown, both in Thrissur district.
6. ICAR's KVK page has typo-grade addresses ("Wynad", "PalghAt") — normalised to official Kerala district spellings.

---

## Deliverable 2 — NSQF gaps for Kerala

Kerala's defining sectors and what your 7 SSCs cover: **fisheries** (gap — QPs verified and delivered), **tourism & hospitality** (gap — delivered), **healthcare** (gap — delivered in the TN pack, reuse), **it_ites** (gap), **rubber/plantation** (gap — no dedicated SSC; ASCI holds plantation-adjacent QPs), **handloom** (gap — you have no handloom SSC beyond CSDCI/TSC). Delivered QPs: `QG-04-AG-03236-2024-V2-ASCI` Fish Seed Grower (L4, 40th NSQC 2024 — note the new NCrF-era code format replacing FIS/Q), `QG-05-AG-01263-2023-V1-CUTM` Fisheries Post Harvest Supervisor (L5), `AGR/Q4910` Ornamental Fish Farmer (flexible low-education entry), `THC/Q2902` Food Delivery Associate (L3), `THC/Q3008` Street Food Vendor (L4, entry = basic literacy — ideal for voice-first low-literacy users), `THC/Q0102` Front Office Associate (L4). Notional hours again null where the register excerpt didn't print them.

## Deliverable 4 — Kerala specifics

Central rules unchanged (see TN pack). Kerala layer: SCDD implements; SCSP 2022-23 puts Rs 4,900 lakh on training/HRD with MRS finishing schools and district PETCs; Digital University Kerala runs **1-year residential PM-AJAY programmes** (Blockchain/Cyber Security/PCB design) — a live long-term-category example. No state trade list found online; say so plainly.

## Deliverable 5

All 14 districts covered; 2 cite official MSME district profiles (Kannur, Kottayam — both flagged for age), 1 cites a course-list source (Thrissur/KVASU, TVM/ASAP), the rest are LIKELY with `source: null`. Before the demo, pull the remaining `dcmsme.gov.in` Kerala profiles (MSME-DI Thrissur compiles all 14) + Kerala Economic Review (State Planning Board).

## Next state

Say **"next"** for **Karnataka** (31 districts — larger; plan: DAKC/ITI lists, RSETIs by sponsor bank, KVKs via UAS Dharwad/Bengaluru/Mandya, PM-AJAY via Dr. B.R. Ambedkar Development Corporation).
