# Brief: finish the IVR + WhatsApp channels for JanDwar

Copy everything below the line into your new chat as the first message, and
attach `JanDwar-IVR-WhatsApp-Handoff.zip`.

---

## Your job

You are taking over the **server-side channels** of a Smart India Hackathon
2026 project. A working prototype already exists in the attached zip. Your job
is to take it from "runs locally, proven by simulation" to "a real phone call
and a real WhatsApp thread work end to end."

**You are not building the Android app.** That is finished and owned by someone
else. Do not modify anything under `assets/` — those JSON files are the shared
catalogue and the app reads the identical files. Treat them as read-only input.

## The problem statement

**SIH 2026, PS 26097** — *"AI-Driven voice Assistant for livelihood Mapping and
NSQF-Aligned Skilling Recommendations for SC Communities under the GIA
component of PM-AJAY."*

The system interviews a person from a Scheduled Caste community, by voice, in
their own language, and recommends government-funded skill-training courses
that suit them. The interview must feel like a conversation, not a form. Users
may be non-literate, on feature phones, with poor connectivity.

The Android app covers smartphone users. **You cover everyone else: a plain
phone call (IVR) and WhatsApp.**

## What already works

Run it first, before changing anything:

```bash
cd server
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Open <http://localhost:8000>. There is a three-tab console — App/Kiosk, IVR
call, WhatsApp — with a **Run a scripted demo** button. Try it in English and
in Tamil. It boots with **no API keys of any kind** and completes a full
interview with real recommendations.

Already built and tested:

| | Status |
|---|---|
| 8-slot interview state machine, 6 languages | Done |
| Rule-based NLU, 1,480 surface forms, script-aware matching | Done |
| NSQF recommender over 452 real job roles (303 PM-AJAY fundable) | Done |
| `/ivr/*` webhooks — Twilio TwiML, speech **and** DTMF keypad | Done, simulated only |
| `/whatsapp/webhook` — real Meta Cloud API payload shape | Done, simulated only |
| Browser console that drives the **real** webhooks | Done |
| Bhashini ASR/TTS adapter | Written, **never run against the live API** |
| Ollama adapter (optional LLM) | Written, **never run against a live model** |

The IVR and WhatsApp tabs in the console are not mock-ups — they POST to the
actual webhook endpoints and display the actual TwiML returned. But **no real
phone call and no real WhatsApp message has ever been through this.** Closing
that gap is the job.

## Architecture, in one picture

```
   phone call ──► /ivr/voice, /ivr/lang, /ivr/turn ──┐
   WhatsApp   ──► /whatsapp/webhook ─────────────────┤
   browser    ──► /api/session, /api/say ────────────┤
                                                     ▼
                                          core/engine.py   (interview state machine)
                                                     │
                            ┌────────────────────────┼───────────────────────┐
                            ▼                        ▼                       ▼
                     core/nlu.py             adapters/llm.py        core/recommend.py
                   (rules, always)         (Ollama, optional)     (deterministic scorer)
                            │                                              │
                     core/lexicon.py                                assets/*.json
```

**Channels own no interview logic.** They translate between a transport (TwiML,
Meta JSON, HTTP JSON) and two calls: `engine.start(lang, channel)` and
`engine.answer(session, text)`. If you find yourself writing interview rules in
`channels/`, stop — it belongs in `core/`.

## The rule you must not break

**The LLM does language. The deterministic engine does the recommendation.**

`adapters/llm.py` may help extract slots from a rambling sentence. It must
**never** choose or invent a course. Every recommendation carries a real QP
code (`AGR/Q4102`), a real NSQF level and real notional hours, selected from
the 452 rows in `assets/job_roles.json`. This feeds a government funding
decision — a hallucinated QP code sends a real person to a training centre for
a course that does not exist.

Three reasons, so you don't "improve" this later:

1. **Correctness** — the recommender can only *select from* the catalogue, never generate.
2. **Latency** — silence beyond ~1.5 s on a phone call reads as a dropped line. Rules answer in ~1 ms; a 3B model on CPU takes 4–15 s.
3. **Availability** — the whole point of IVR is reaching places where infrastructure is thin. With every optional service down, the interview must still complete. Today it does.

## What to build, in order

### 1. Make a real phone call work (highest value)

The code is written; it has never met Twilio. Expect the first call to expose
something.

- The server must be publicly reachable over HTTPS. `render.yaml` is included —
  Render's free tier, `New → Blueprint → Apply`, and `RENDER_EXTERNAL_URL` is
  picked up automatically by `app/config.py`. A `cloudflared` tunnel also works.
- Twilio trial. Buy a **US** number with Voice (Twilio will not sell an
  individual an Indian voice number; Indian DIDs need company KYC under TRAI).
  Trial numbers only accept calls from a **verified** caller ID.
- Point **Voice → A call comes in** at `POST https://<your-url>/ivr/voice`.
- Call it. Fix what breaks. Twilio Console → **Monitor → Logs → Errors** shows
  the exact HTTP response Twilio got.

Known trap, already fixed once — **do not regress it**: Twilio's default voice
is the Basic voice `man`, which cannot speak any Indic language. Sending
`<Say language="ta-IN">` without a matching `voice` attribute produces silence
and drops the call. Every language must name a real Google voice. See the
`VOICE` map at the top of `app/channels/ivr.py`.

Things to verify on a real call, which simulation cannot prove:
- barge-in (caller speaks over the prompt)
- `speechTimeout="auto"` behaving sanely on a noisy rural line
- what Twilio's `ta-IN` recogniser actually returns for Tamil — the rule NLU
  was tuned against expected spellings and may need lexicon additions
  (`assets/lexicon.json` is data; append forms, don't change code)
- a caller who says nothing at all
- a caller who hangs up mid-interview (sessions must expire — `SessionStore` has a 1 h TTL)

### 2. Make a real WhatsApp thread work

- Meta Cloud API, free test number, ~1,000 conversations/month free.
- Webhook: `https://<your-url>/whatsapp/webhook`, verify token from
  `WHATSAPP_VERIFY_TOKEN` (default `jandwar`), subscribe to **messages**.
- Voice notes arrive as `audio`. WhatsApp sends **OGG/Opus**, and
  `adapters/speech.py` currently tells Bhashini the format is `wav`. **This is
  a known bug — fix it.** Either transcode with ffmpeg or pass the correct
  format.
- While no Meta token is set, outbound replies are recorded in an in-memory
  outbox (`GET /whatsapp/outbox/{phone}`) so the console can show them. That is
  a dev aid; with a real token, messages go to Meta and the outbox stays empty.

### 3. Wire up Bhashini properly

The project owner **has a Bhashini account**. Bhashini is the Government of
India's language stack — free, and much better on rural Tamil/Telugu/Kannada
accents than Western speech APIs. For a PM-AJAY submission, using the
Government's own infrastructure is a point in the design's favour.

`adapters/speech.py` implements the two-step ULCA flow (pipeline config, then
compute) but **has never been run against the live API**. Expect the response
shapes to need correcting. Test ASR and TTS separately before wiring them into
a call.

Env vars: `BHASHINI_USER_ID`, `BHASHINI_ULCA_KEY`, `BHASHINI_INFERENCE_KEY`.
**Never commit these.** Never ask the user to paste a key into chat — tell them
which dashboard field to copy it into.

### 4. Only then, Ollama

`JANDWAR_OLLAMA=1`, `ollama pull qwen2.5:3b-instruct` (better Indic coverage
than Llama 3.2 3B at the same size). Verify it improves slot extraction on
rambling multi-slot sentences, behind a hard timeout, and that the system is
identical when it's off.

## Gotchas already paid for — don't rediscover these

These were real bugs found by auditing the NLU. The fixes are in
`server/app/core/` and must not be undone:

- **Fuzzy matching tuned on English is harmful on Indic scripts.** One codepoint is a whole syllable. At the original tolerances there were 35 cross-category collisions: Tamil `ஐந்தாம்`(5th)≈`பத்தாம்`(10th), `பட்டம்`(degree)≈`வட்டம்`(district), Hindi `यहीं`≈`नहीं`. Three rules fix it together — **exact-wins** (a token that is a known form matches only its own categories), **first character must agree**, and **script-aware tolerance** (Indic 0/1/2 at ≤5/≤8/more; Latin 0/1/2 at ≤3/≤6/more). Any one alone is insufficient.
- **Normalise the lexicon forms with the same function as the utterance**, or every punctuated form silently becomes dead data.
- **Latin single-word forms must match a whole token, not a substring.** `inter` (Intermediate) was matching inside "interested" and recording Class 12.
- **Precedence lists cannot express specificity.** "pre university" contains "university". Use longest-match (`Lexicon.best_match`).
- **Any form containing a digit must match exactly.** `10th` and `12th` are one edit apart.
- **Only the slot being answered may overwrite a value.** Incidental extraction may fill an empty slot but never rewrite an answered one, or "I am interested in dairy" rewrites a stated Class 10 into Class 12.
- **Free-text occupation slots must always be asked out loud.** `FAMILY_OCCUPATION`, `CURRENT_LIVELIHOOD` and `INTERESTS` share vocabulary, so "my family farms" fills all three and silently skips two required questions. See `INFERABLE` in `core/engine.py`.
- **The catalogue advertises 516 roles; 452 are usable.** Both the app and the server filter invalid names. Report 516 raw / 452 usable / 303 fundable.

## Constraints

- **Branding is "JanDwar".** Not "Thozhil Thunai" — that name is retired.
- **Never ask the user for an API key in chat.** Placeholders and dashboard instructions only.
- **It must still boot with an empty environment.** Every external service is an optional adapter with a working fallback. If you add a dependency that breaks the zero-key path, you have broken the most important property of this system.
- Don't duplicate interview logic into the channels.
- Don't edit `assets/*.json` — the Android app ships the identical files.

## Definition of done

1. A real phone call to a real number completes the full 8-question interview in Tamil and reads back NSQF course recommendations.
2. The same interview completes entirely on the **keypad**, with no speech recognition at all.
3. A real WhatsApp voice note in Hindi is transcribed, answered, and the reply comes back as both a voice note and text.
4. With all keys removed, the server still boots and the browser console still completes an interview.
5. A short `RUNBOOK.md`: what you configured, what it costs, and how to bring it up for a demo in under five minutes.

## Cost reality

₹0 for everything above except a production Indian phone number (Exotel,
roughly ₹500–1,500/month, needs company KYC). Ollama free, Bhashini free,
Render free tier, WhatsApp Cloud API free tier, Twilio trial credit. Say so
explicitly in the runbook — "₹0 to run, one phone number away from production"
is a strong line for the evaluation.

## What's in the zip

```
server/
  app/
    main.py, config.py, deps.py
    core/      data, lexicon, nlu, recommend, engine   ← the shared brain
    adapters/  llm (Ollama), speech (Bhashini)          ← optional, untested live
    channels/  api, ivr, whatsapp                       ← your main surface
    static/    index.html                               ← the 3-tab console
  data/flow.json          interview questions, 8 slots × 6 languages
  requirements.txt
  DEPLOY.md               hosting, env vars, what to demo
  IVR.md                  how IVR works + Twilio walkthrough + keypad map
assets/                   READ-ONLY catalogue shared with the Android app
render.yaml               one-click Render blueprint
```

Start by running it and doing a Tamil demo in the console. Then make a phone
ring.
