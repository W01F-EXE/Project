"""
Port of ai/OnDeviceNlu.kt -- slot extraction for all six languages.

Deterministic, offline, instant. This is the floor the service always has:
when Ollama is not running, or the model returns nonsense, or the call has to
be answered in 300 ms, this is what understands the caller.

Kept deliberately faithful to the Kotlin, including detector precedence, so
the same sentence fills the same slots on every channel.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field

from . import data
from .lexicon import Lexicon

NO_CONSTRAINT = "None"

SLOTS = ["EDUCATION", "FAMILY_OCCUPATION", "CURRENT_LIVELIHOOD", "INTERESTS",
         "PREFERENCE", "MOBILITY", "CONSTRAINTS", "DISTRICT"]

EDU_ORDER = [
    ("edu.none", "class5"),
    ("edu.iti_diploma", "iti_diploma"),
    ("edu.graduate", "graduate"),
    ("edu.class12", "class12"),
    ("edu.class10", "class10"),
    ("edu.class8", "class8"),
    ("edu.class5", "class5"),
]

INTEREST_KEYS = ["dairy", "cattle", "goat", "poultry", "farming",
                 "food", "machine", "textile", "construction", "tailor"]

OCCUPATION_ORDER = [
    ("occ.government", "Government service"),
    ("occ.driver", "Driving"),
    ("occ.fishing", "Fishing"),
    ("occ.coolie", "Daily wage labour"),
    ("occ.shop", "Small shop"),
    ("interest.dairy", "Dairy farming"),
    ("interest.cattle", "Cattle rearing"),
    ("interest.goat", "Goat rearing"),
    ("interest.poultry", "Poultry"),
    ("interest.tailor", "Tailoring"),
    ("interest.textile", "Weaving"),
    ("interest.construction", "Construction work"),
    ("interest.food", "Cooking / catering"),
    ("interest.machine", "Machine work / repair"),
    ("interest.farming", "Farming"),
]

NON_ANSWERS = {"yes", "no", "ok", "okay", "hmm", "nothing", "dont know", "don't know",
               "சரி", "இல்லை", "தெரியாது", "हाँ", "नहीं", "पता नहीं"}

DISTRICT_ALIASES = {
    "Ariyalur": ["அரியலூர்", "अरियलूर"],
    "Chengalpattu": ["செங்கல்பட்டு", "chengalpet", "चेंगलपट्टू"],
    "Chennai": ["சென்னை", "चेन्नई", "madras", "చెన్నై", "ಚೆನ್ನೈ", "ചെന്നൈ"],
    "Coimbatore": ["கோயம்புத்தூர்", "कोयंबटूर", "kovai", "கோவை", "కోయంబత్తూరు", "ಕೊಯಮತ್ತೂರು"],
    "Cuddalore": ["கடலூர்", "कुड्डालोर"],
    "Dharmapuri": ["தர்மபுரி", "धर्मपुरी"],
    "Dindigul": ["திண்டுக்கல்", "डिंडीगुल"],
    "Erode": ["ஈரோடு", "इरोड", "ఈరోడ్", "ಈರೋಡ್"],
    "Kallakurichi": ["கள்ளக்குறிச்சி", "कल्लाकुरिची"],
    "Kancheepuram": ["காஞ்சிபுரம்", "कांचीपुरम", "kanchipuram"],
    "Kanniyakumari": ["கன்னியாகுமரி", "कन्याकुमारी", "kanyakumari", "nagercoil"],
    "Karur": ["கரூர்", "करूर"],
    "Krishnagiri": ["கிருஷ்ணகிரி", "कृष्णागिरी"],
    "Madurai": ["மதுரை", "मदुरै", "మదురై", "ಮಧುರೈ", "മധുര"],
    "Mayiladuthurai": ["மயிலாடுதுறை", "मयिलादुथुरै"],
    "Nagapattinam": ["நாகப்பட்டினம்", "नागपट्टिनम"],
    "Namakkal": ["நாமக்கல்", "नामक्कल"],
    "Nilgiris": ["நீலகிரி", "नीलगिरी", "ooty", "உதகமண்டலம்"],
    "Perambalur": ["பெரம்பலூர்", "पेरम्बलूर"],
    "Pudukkottai": ["புதுக்கோட்டை", "पुदुक्कोट्टई"],
    "Ramanathapuram": ["இராமநாதபுரம்", "रामनाथपुरम", "ramnad"],
    "Ranipet": ["இராணிப்பேட்டை", "रानीपेट"],
    "Salem": ["சேலம்", "सेलम", "సేలం", "ಸೇಲಂ"],
    "Sivaganga": ["சிவகங்கை", "शिवगंगा", "sivagangai"],
    "Tenkasi": ["தென்காசி", "तेनकासी"],
    "Thanjavur": ["தஞ்சாவூர்", "तंजावुर", "tanjore"],
    "Theni": ["தேனி", "थेनी"],
    "Thoothukudi": ["தூத்துக்குடி", "तूतुकुडी", "tuticorin"],
    "Tiruchirappalli": ["திருச்சிராப்பள்ளி", "तिरुचिरापल्ली", "trichy", "திருச்சி"],
    "Tirunelveli": ["திருநெல்வேலி", "तिरुनेलवेली", "nellai"],
    "Tirupattur": ["திருப்பத்தூர்", "तिरुपत्तूर"],
    "Tiruppur": ["திருப்பூர்", "तिरुपुर", "tirupur"],
    "Tiruvallur": ["திருவள்ளூர்", "तिरुवल्लूर"],
    "Tiruvannamalai": ["திருவண்ணாமலை", "तिरुवन्नामलई"],
    "Tiruvarur": ["திருவாரூர்", "तिरुवारूर"],
    "Vellore": ["வேலூர்", "वेल्लोर"],
    "Villupuram": ["விழுப்புரம்", "विल्लुपुरम", "viluppuram"],
    "Virudhunagar": ["விருதுநகர்", "विरुधुनगर"],
}


@dataclass
class Fragment:
    """Mirror of ai/ProfileFragment.kt."""
    edu: str | None = None
    district: str | None = None
    family_occupation: str | None = None
    current_livelihood: str | None = None
    interests: list[str] = field(default_factory=list)
    skills: list[str] = field(default_factory=list)
    preference: str | None = None
    mobility: str | None = None
    physical_constraints: str | None = None
    local_opportunity: str | None = None

    def is_filled(self, slot: str) -> bool:
        return {
            "EDUCATION": bool(self.edu),
            "FAMILY_OCCUPATION": bool(self.family_occupation),
            "CURRENT_LIVELIHOOD": bool(self.current_livelihood),
            "INTERESTS": bool(self.interests) or bool(self.skills),
            "PREFERENCE": bool(self.preference),
            "MOBILITY": bool(self.mobility),
            "CONSTRAINTS": bool(self.physical_constraints),
            "DISTRICT": bool(self.district),
        }[slot]

    def missing_slots(self) -> list[str]:
        return [s for s in SLOTS if not self.is_filled(s)]

    def filled_count(self) -> int:
        return sum(1 for s in SLOTS if self.is_filled(s))

    #: slot name -> the Fragment field it owns
    SLOT_FIELD = {
        "EDUCATION": "edu",
        "FAMILY_OCCUPATION": "family_occupation",
        "CURRENT_LIVELIHOOD": "current_livelihood",
        "PREFERENCE": "preference",
        "MOBILITY": "mobility",
        "CONSTRAINTS": "physical_constraints",
        "DISTRICT": "district",
    }

    def merge(self, other: "Fragment", answering: str | None = None) -> "Fragment":
        """
        Fold `other` in.

        Only the slot actually being answered may *overwrite* an existing
        value. Everything else may only fill a gap. Multi-slot extraction is
        worth having -- one sentence can fill three slots -- but without this
        rule an incidental mention later in the interview silently rewrites an
        earlier answer: "I am interested in dairy" turned a stated Class 10
        into Class 12 (via "inter") and replaced "coolie work" with "dairy
        farming".
        """
        owned = self.SLOT_FIELD.get(answering or "")
        for f in ("edu", "district", "family_occupation", "current_livelihood",
                  "preference", "mobility", "physical_constraints", "local_opportunity"):
            v = getattr(other, f)
            if v and (not getattr(self, f) or f == owned):
                setattr(self, f, v)
        for i in other.interests:
            if i not in self.interests:
                self.interests.append(i)
        for s in other.skills:
            if s not in self.skills:
                self.skills.append(s)
        return self

    def to_dict(self) -> dict:
        return {
            "education": self.edu, "district": self.district,
            "familyOccupation": self.family_occupation,
            "currentLivelihood": self.current_livelihood,
            "interests": self.interests, "skills": self.skills,
            "preference": self.preference, "mobility": self.mobility,
            "physicalConstraints": self.physical_constraints,
            "localOpportunity": self.local_opportunity,
        }


_PUNCT = re.compile(
    "[" + re.escape("".join(chr(i) for i in range(0x21, 0x7F)
                            if unicodedata.category(chr(i)).startswith("P")
                            and chr(i) != "+")) + "]")


def normalise(t: str) -> str:
    return re.sub(r"\s+", " ", _PUNCT.sub(" ", t.lower())).strip()


class Nlu:
    def __init__(self):
        self.lex = Lexicon(data.lexicon_forms())
        self._districts = self._build_district_index()

    # ── helpers ────────────────────────────────────────────────────────────
    def has(self, s, key):
        return self.lex.has(s, key)

    def has_exact(self, s, key):
        return self.lex.has_exact(s, key)

    def _build_district_index(self):
        out = []
        for d in data.districts().get("all", []):
            forms = [d.lower()] + [a.lower() for a in DISTRICT_ALIASES.get(d, [])]
            for f in forms:
                out.append((d, f))
        out.sort(key=lambda p: -len(p[1]))
        return out

    # ── detectors ──────────────────────────────────────────────────────────
    def detect_district(self, s, original):
        lo = original.lower()
        for name, form in self._districts:
            if form in s or form in lo:
                return name
        return None

    def detect_education(self, s):
        # Specificity, not list order: "pre university" must not be read as
        # "university". Falls back to EDU_ORDER precedence on a tie.
        cat = self.lex.best_match(s, [k for k, _ in EDU_ORDER])
        if cat:
            return dict(EDU_ORDER)[cat]
        return None

    def detect_education_loose(self, s):
        e = self.detect_education(s)
        if e:
            return e
        m = re.search(r"\b(\d{1,2})\b", s)
        if m:
            n = int(m.group(1))
            if n >= 13:
                return "graduate"
            if n in (11, 12):
                return "class12"
            if n in (9, 10):
                return "class10"
            if 6 <= n <= 8:
                return "class8"
            if 1 <= n <= 5:
                return "class5"
        if self.has(s, "marker.no"):
            return "class5"
        return None

    def detect_preference(self, s):
        if self.has(s, "pref.self_strong"):
            return "pref_self"
        if self.has(s, "pref.wage_strong"):
            return "pref_wage"
        if self.has(s, "pref.self_weak"):
            return "pref_self"
        if self.has(s, "pref.wage_weak"):
            return "pref_wage"
        return None

    def detect_preference_strict(self, s):
        if self.has_exact(s, "pref.self_strong"):
            return "pref_self"
        if self.has_exact(s, "pref.wage_strong"):
            return "pref_wage"
        return None

    def detect_preference_loose(self, s):
        p = self.detect_preference(s)
        if p:
            return p
        if any(w in s for w in ("first", "one", "1", "முதல்", "पहला")):
            return "pref_self"
        if any(w in s for w in ("second", "two", "2", "இரண்டு", "दूसरा")):
            return "pref_wage"
        return None

    def detect_mobility(self, s):
        if self.has(s, "mob.state"):
            return "state"
        if self.has(s, "mob.district"):
            return "district"
        if self.has(s, "mob.local"):
            return "local"
        if self.has(s, "mob.anywhere"):
            return "state"
        return None

    def detect_mobility_strict(self, s):
        if self.has_exact(s, "mob.state"):
            return "state"
        if self.has_exact(s, "mob.district"):
            return "district"
        if self.has_exact(s, "mob.local"):
            return "local"
        return None

    def detect_mobility_loose(self, s):
        m = self.detect_mobility(s)
        if m:
            return m
        if self.has(s, "marker.yes"):
            return "district"
        if self.has(s, "marker.no"):
            return "local"
        return None

    def detect_interests(self, s):
        return [k for k in INTEREST_KEYS if self.has(s, "interest." + k)]

    def mentions_family(self, s):
        return self.has(s, "marker.family")

    def detect_occupation(self, s):
        for key, label in OCCUPATION_ORDER:
            if self.has(s, key):
                return label
        return None

    def detect_student_status(self, s):
        if self.has(s, "marker.student"):
            return "Student"
        if self.has(s, "marker.unemployed"):
            return "Looking for work"
        return None

    def detect_constraints(self, s, original):
        return original.strip()[:120] if self.has(s, "marker.constraint") else None

    @staticmethod
    def free_text(original):
        t = original.strip()
        if len(t) < 2 or len(t) > 140:
            return None
        if t.lower() in NON_ANSWERS:
            return None
        return t[0].upper() + t[1:]

    # ── extraction ─────────────────────────────────────────────────────────
    def extract(self, raw: str, lang: str = "en") -> Fragment:
        frag = Fragment()
        text = (raw or "").strip()
        if not text:
            return frag
        s = normalise(text)

        frag.district = self.detect_district(s, text)
        frag.edu = self.detect_education(s)
        # Strict: this utterance may be answering something else entirely.
        frag.preference = self.detect_preference_strict(s)
        frag.mobility = self.detect_mobility_strict(s)
        for i in self.detect_interests(s):
            if i not in frag.interests:
                frag.interests.append(i)
        frag.physical_constraints = self.detect_constraints(s, text)

        occ = self.detect_occupation(s)
        if occ:
            if self.mentions_family(s):
                frag.family_occupation = occ
            else:
                frag.current_livelihood = occ
        if not frag.current_livelihood:
            st = self.detect_student_status(s)
            if st:
                frag.current_livelihood = st
        return frag

    def extract_for_slot(self, raw: str, lang: str, slot: str) -> Fragment:
        frag = self.extract(raw, lang)
        text = (raw or "").strip()
        if not text:
            return frag
        s = normalise(text)

        if slot == "EDUCATION":
            v = self.detect_education_loose(s)
            if v:
                frag.edu = v
        elif slot == "FAMILY_OCCUPATION":
            if not frag.family_occupation:
                frag.family_occupation = frag.current_livelihood or self.free_text(text)
                if frag.current_livelihood and self.mentions_family(s):
                    frag.current_livelihood = None
        elif slot == "CURRENT_LIVELIHOOD":
            if not frag.current_livelihood:
                frag.current_livelihood = self.free_text(text)
        elif slot == "INTERESTS":
            if not frag.interests:
                ft = self.free_text(text)
                if ft:
                    frag.skills.append(ft)
        elif slot == "PREFERENCE":
            v = self.detect_preference_loose(s)
            if v:
                frag.preference = v
        elif slot == "MOBILITY":
            v = self.detect_mobility_loose(s)
            if v:
                frag.mobility = v
        elif slot == "CONSTRAINTS":
            # "No" is a real answer here, not a failure to understand.
            if self.has_exact(s, "marker.constraint"):
                frag.physical_constraints = text[:120]
            elif self.has(s, "marker.no"):
                frag.physical_constraints = NO_CONSTRAINT
            elif self.has(s, "marker.yes"):
                frag.physical_constraints = text[:120]
            elif len(text) >= 2:
                frag.physical_constraints = text[:120]
        # DISTRICT needs an exact hit, already handled in extract().
        return frag
