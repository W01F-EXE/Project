The controller monitors things such as:

### Temperature

Keeps the process near the target temperature.

### Pressure

Maintains the desired reduced pressure.

### Flow

Ensures the recirculation pump is actually working.

### Overheat protection

Stops heating when temperature becomes unsafe.

### Automatic shutdown

Provides fault handling.


and more......like PT100/RTD + pressure transducer + flow sensor + liquid-level sensor + current sensing + independent thermal cutoff.