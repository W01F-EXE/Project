**Non-cavitation acoustic microstreaming** works by using high-frequency sound waves to create gentle, continuous fluid currents that sweep away natural boundary barriers, speeding up extraction without harming delicate compounds.

Here is how the process works step by step:

1. Generating Sound Waves

- A **100 kHz piezoelectric transducer** vibrates rapidly at a high frequency.
- This vibration sends acoustic energy directly down into the liquid mixture.

2. Creating Eckart Streaming

- The sound waves drive a steady, continuous movement within the fluid known as **Eckart streaming**.
- Unlike higher-energy ultrasound, this process achieves fluid motion **without cavitation** (the violent forming and collapsing of microscopic bubbles), which protects fragile, heat-sensitive molecules.

3. Disrupting the Vapor Boundary Layer

- At the liquid-air interface, a restrictive **vapor boundary layer** normally forms and slows down vaporization.
- The acoustic microstreaming violently ripples this boundary, shattering the layer and allowing vapors to escape smoothly.

4. Stripping the Nernst Layer

- Soluble herbal particles are typically surrounded by a stagnant, microscopic fluid barrier called the **Nernst layer**, which slows down how fast compounds can dissolve out.
- The localized fluid currents sweep this stagnant layer away from the surface of the herbal particles.

Key Advantages

- **Preserves Phytochemicals:** Eliminating bubble implosions (cavitation) prevents the degradation of delicate plant compounds.
- **Faster Extraction:** Breaking down both boundary layers maximizes the **mass transfer**, allowing the liquid to pull active ingredients out of the herbs much faster.




![[Pasted image 20260905133520.jpg]]