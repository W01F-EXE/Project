**Vacuum-reduced vapor pressure** is a method that allows a liquid to boil and vaporize at a much lower temperature than normal by lowering the air pressure inside a sealed container.

In a typical environment at sea level, water boils at **100 °C** under **1.0 atm** of atmospheric pressure. This diagram shows how altering that environment changes the boiling mechanics:

1. Removing Air Pressure

- A **12 V diaphragm pump** constantly sucks air out of the sealed brewing chamber.
- This action reduces the air pressure in the empty space above the liquid (the headspace) down to **0.00 atm** relative or **0.58 atm absolute**.

2. Lowering the Boiling Point

- Boiling occurs when the vapor pressure of a liquid equals the surrounding air pressure.
- Because the pump removes almost half of the atmospheric weight pressing down on the water, the water molecules can escape into a gas phase much more easily.
- This drops the boiling point of the water from 100 °C down to **~85 °C**.

3. Creating a Vapor Gradient

- Even without intense, violent bubbling (vigorous boiling), a steep **vapor-pressure gradient** is formed.
- The liquid transitions into a steady vapor state rapidly at this lower temperature, which protects delicate compounds (like tea leaves or coffee grounds) from being scorched or over-extracted by excessive heat.


### The key benefit

Instead of:

**high temperature + vigorous boiling**

the machine attempts:

**lower temperature + controlled evaporation**

That can potentially be gentler.

### But there is an important engineering issue

The vapor system must be designed properly.

We need:

- Pressure sensor
- Vacuum regulation
- Condensation/steam handling
- Check valves
- Vacuum-rated chamber
- Overpressure protection
- Leak-resistant seals

A 12 V pump by itself does **not** guarantee 0.58 atm. You need closed-loop pressure control.





![[Pasted image 20260905121431.png]]