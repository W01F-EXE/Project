The induction coil carries alternating current, producing an alternating magnetic field.

That magnetic field induces electrical currents in a conductive metal vessel.

Those currents generate heat within the vessel material itself.


#BriefExplanation :

1. Alternating Current in the Coil

- Electricity flows through a copper coil located just beneath the surface of the appliance.

- This electricity is an **alternating current (AC)**, meaning it changes direction thousands of times every second.

2. Creating a Magnetic Field

- As the alternating current rushes through the coil, it creates a rapidly changing **magnetic field** right above it.

- This magnetic field passes right through non-metal surfaces (like a glass cooktop) without losing energy.

3. Inducing Eddy Currents

- When you place a conductive metal vessel (like an iron or steel pan) into the magnetic field, it disrupts the field.

- This forces swirling electrical currents, called **eddy currents**, to spin rapidly inside the bottom of the metal pan.

4. Generating Heat

- The metal pan offers resistance to these swirling electrical currents.

- Just like rubbing your hands together creates friction and warmth, this electrical resistance turns the energy into **heat** instantly inside the pan material.

Key Advantages

- **Fast and Direct:** The heat is made inside the pan itself, not transferred from a hot burner.

- **Energy Efficient:** Very little heat escapes into the surrounding air.

- **Safe:** The cooktop surface stays relatively cool because it only warms up from contact with the hot pan.





  ![[Pasted image 20260905121720.png]]