This is probably one of the most cost-effective ideas in the entire design.

Instead of leaving all the decoction as a deep pool, a pump continuously takes liquid from the bottom and sends it to a nozzle ring.

The nozzle sprays the liquid over the vessel.

The liquid then flows downward as a thin film.

### Concept

Instead of:

**large static pool**

you create:

**thin moving liquid layer**

A thin film has a much larger liquid-air interface relative to its liquid volume.

That can improve:

- Mass transfer
- Evaporation
- Mixing
- Contact with heated surfaces
  
we should work on:
- Nozzle design
- Droplet size
- Film thickness
- Flow rate
- Vessel geometry
- Liquid viscosity


Important Note for efficiency:
For a student/hackathon prototype, this mechanism can provide a substantial benefit without requiring an extremely expensive technology.



![[Pasted image 20260905131915.png]]